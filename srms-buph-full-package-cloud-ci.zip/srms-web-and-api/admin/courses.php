<?php
$pageTitle = 'Courses';
require_once __DIR__ . '/includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_course'])) {
    $code   = strtoupper(clean($_POST['course_code']));
    $title  = clean($_POST['course_title']);
    $unit   = (int) $_POST['unit'];
    $dept   = clean($_POST['department']);
    $level  = clean($_POST['level']);
    $sem    = clean($_POST['semester']);
    $session= clean($_POST['session']);

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO courses (course_code, course_title, unit, department, level, semester, session)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([$code, $title, $unit, $dept, $level, $sem, $session]);
        set_flash('success', "Course $code created successfully.");
    } catch (PDOException $e) {
        set_flash('error', 'Could not create course — it may already exist for that session/semester/level.');
    }
    redirect('courses.php');
}

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM courses WHERE id = ?")->execute([(int) $_GET['delete']]);
    set_flash('success', 'Course deleted.');
    redirect('courses.php');
}

$courses = $pdo->query("SELECT * FROM courses ORDER BY session DESC, semester, level, course_code")->fetchAll();
?>

<div class="flex-between">
  <h2>Courses</h2>
</div>

<div class="grid cols-2">
  <div class="card">
    <h3>Add New Course</h3>
    <form method="POST">
      <input type="hidden" name="add_course" value="1">
      <div class="grid cols-2">
        <div class="form-group">
          <label>Course Code</label>
          <input type="text" name="course_code" placeholder="e.g. COM 201" required>
        </div>
        <div class="form-group">
          <label>Unit(s)</label>
          <input type="number" name="unit" min="1" max="6" value="2" required>
        </div>
      </div>
      <div class="form-group">
        <label>Course Title</label>
        <input type="text" name="course_title" placeholder="e.g. Data Structures and Algorithms" required>
      </div>
      <div class="grid cols-2">
        <div class="form-group">
          <label>Department</label>
          <input type="text" name="department" placeholder="e.g. Computer Science" required>
        </div>
        <div class="form-group">
          <label>Level</label>
          <select name="level" required>
            <option value="ND1">ND1</option>
            <option value="ND2">ND2</option>
            <option value="HND1">HND1</option>
            <option value="HND2">HND2</option>
          </select>
        </div>
      </div>
      <div class="grid cols-2">
        <div class="form-group">
          <label>Semester</label>
          <select name="semester" required>
            <option value="First">First Semester</option>
            <option value="Second">Second Semester</option>
          </select>
        </div>
        <div class="form-group">
          <label>Session</label>
          <input type="text" name="session" placeholder="e.g. 2025/2026" required>
        </div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Add Course</button>
    </form>
  </div>

  <div class="card">
    <h3>All Courses (<?= count($courses) ?>)</h3>
    <div class="table-wrap" style="max-height: 480px; overflow-y: auto;">
      <table>
        <thead><tr><th>Code</th><th>Title</th><th>Level</th><th>Semester</th><th>Session</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($courses as $c): ?>
          <tr>
            <td><?= htmlspecialchars($c['course_code']) ?></td>
            <td><?= htmlspecialchars($c['course_title']) ?></td>
            <td><?= htmlspecialchars($c['level']) ?></td>
            <td><?= htmlspecialchars($c['semester']) ?></td>
            <td><?= htmlspecialchars($c['session']) ?></td>
            <td><a href="?delete=<?= $c['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this course?')">Delete</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$courses): ?><tr><td colspan="6" class="text-muted">No courses added yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
