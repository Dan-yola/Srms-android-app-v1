<?php
$pageTitle = 'Student Profile';
require_once __DIR__ . '/includes/header.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    echo '<div class="alert alert-error">Student not found.</div>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Handle suspend/activate toggle
if (isset($_GET['toggle'])) {
    $newStatus = $student['status'] === 'active' ? 'suspended' : 'active';
    $pdo->prepare("UPDATE students SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
    redirect('student_view.php?id=' . $id);
}

$regs = $pdo->prepare(
    "SELECT cr.*, c.course_code, c.course_title FROM course_registrations cr
     JOIN courses c ON c.id = cr.course_id WHERE cr.student_id = ? ORDER BY cr.registered_at DESC"
);
$regs->execute([$id]);
$registrations = $regs->fetchAll();

$res = $pdo->prepare(
    "SELECT r.*, c.course_code, c.course_title FROM results r
     JOIN courses c ON c.id = r.course_id WHERE r.student_id = ? ORDER BY r.uploaded_at DESC"
);
$res->execute([$id]);
$results = $res->fetchAll();

$proj = $pdo->prepare(
    "SELECT p.*, c.course_code FROM projects p
     JOIN courses c ON c.id = p.course_id WHERE p.student_id = ? ORDER BY p.uploaded_at DESC"
);
$proj->execute([$id]);
$projects = $proj->fetchAll();
?>

<div class="flex-between">
  <h2><?= htmlspecialchars($student['full_name'] ?: $student['matric_no']) ?></h2>
  <a href="students.php">&larr; Back to Students</a>
</div>

<div class="grid cols-2">
  <div class="card">
    <h3>Profile</h3>
    <p><strong>Matric No:</strong> <?= htmlspecialchars($student['matric_no']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($student['email']) ?></p>
    <p><strong>Phone:</strong> <?= htmlspecialchars($student['phone'] ?: '—') ?></p>
    <p><strong>Department:</strong> <?= htmlspecialchars($student['department'] ?: '—') ?></p>
    <p><strong>Level:</strong> <?= htmlspecialchars($student['level'] ?: '—') ?></p>
    <p><strong>Status:</strong> <span class="badge-pill <?= $student['status'] === 'active' ? 'badge-green' : 'badge-red' ?>"><?= ucfirst($student['status']) ?></span></p>
    <a class="btn btn-sm <?= $student['status'] === 'active' ? 'btn-danger' : 'btn-primary' ?>" href="?id=<?= $id ?>&toggle=1" onclick="return confirmAction('Change this student\'s status?')">
      <?= $student['status'] === 'active' ? 'Suspend Student' : 'Reactivate Student' ?>
    </a>
  </div>

  <div class="card">
    <h3>Course Registrations (<?= count($registrations) ?>)</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Course</th><th>Session</th><th>Semester</th><th>RRR</th></tr></thead>
        <tbody>
        <?php foreach ($registrations as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['course_code']) ?></td>
            <td><?= htmlspecialchars($r['session']) ?></td>
            <td><?= htmlspecialchars($r['semester']) ?></td>
            <td><?= htmlspecialchars($r['remita_rrr']) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$registrations): ?><tr><td colspan="4" class="text-muted">No registrations yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="card">
  <h3>Results</h3>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Course</th><th>Session</th><th>Semester</th><th>CA</th><th>Exam</th><th>Total</th><th>Grade</th></tr></thead>
      <tbody>
      <?php foreach ($results as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['course_code']) ?></td>
          <td><?= htmlspecialchars($r['session']) ?></td>
          <td><?= htmlspecialchars($r['semester']) ?></td>
          <td><?= htmlspecialchars($r['ca_score']) ?></td>
          <td><?= htmlspecialchars($r['exam_score']) ?></td>
          <td><?= htmlspecialchars($r['total_score']) ?></td>
          <td><span class="badge-pill badge-gold"><?= htmlspecialchars($r['grade']) ?></span></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$results): ?><tr><td colspan="7" class="text-muted">No results uploaded yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <h3>Project Uploads</h3>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Course</th><th>Title</th><th>Uploaded</th><th>Status</th><th>File</th></tr></thead>
      <tbody>
      <?php foreach ($projects as $p): ?>
        <tr>
          <td><?= htmlspecialchars($p['course_code']) ?></td>
          <td><?= htmlspecialchars($p['title']) ?></td>
          <td><?= htmlspecialchars($p['uploaded_at']) ?></td>
          <td><?= $p['is_duplicate'] ? '<span class="badge-pill badge-red">Duplicate</span>' : '<span class="badge-pill badge-green">Unique</span>' ?></td>
          <td><a href="../uploads/projects/<?= htmlspecialchars($p['file_path']) ?>" target="_blank">Download</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$projects): ?><tr><td colspan="5" class="text-muted">No project uploads yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
