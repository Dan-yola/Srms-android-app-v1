<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$totalStudents  = $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'];
$totalCourses   = $pdo->query("SELECT COUNT(*) c FROM courses")->fetch()['c'];
$totalRegs      = $pdo->query("SELECT COUNT(*) c FROM course_registrations")->fetch()['c'];
$totalProjects  = $pdo->query("SELECT COUNT(*) c FROM projects")->fetch()['c'];
$duplicateCount = $pdo->query("SELECT COUNT(*) c FROM projects WHERE is_duplicate = 1")->fetch()['c'];

$recentStudents = $pdo->query(
    "SELECT * FROM students ORDER BY created_at DESC LIMIT 5"
)->fetchAll();

$recentProjects = $pdo->query(
    "SELECT p.*, s.full_name, s.matric_no, c.course_code
     FROM projects p
     JOIN students s ON s.id = p.student_id
     JOIN courses c ON c.id = p.course_id
     ORDER BY p.uploaded_at DESC LIMIT 5"
)->fetchAll();
?>

<div class="flex-between">
  <h2>Welcome back, <?= htmlspecialchars($_SESSION['admin_name']) ?> 👋</h2>
</div>

<div class="grid cols-4" style="margin-bottom: 24px;">
  <div class="stat-card"><div class="label">Total Students</div><div class="num"><?= $totalStudents ?></div></div>
  <div class="stat-card"><div class="label">Courses</div><div class="num"><?= $totalCourses ?></div></div>
  <div class="stat-card"><div class="label">Course Registrations</div><div class="num"><?= $totalRegs ?></div></div>
  <div class="stat-card"><div class="label">Project Uploads (<?= $duplicateCount ?> flagged duplicate)</div><div class="num"><?= $totalProjects ?></div></div>
</div>

<div class="grid cols-2">
  <div class="card">
    <h3>Recently Registered Students</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Matric No</th><th>Name</th><th>Profile</th></tr></thead>
        <tbody>
        <?php foreach ($recentStudents as $s): ?>
          <tr>
            <td><?= htmlspecialchars($s['matric_no']) ?></td>
            <td><?= htmlspecialchars($s['full_name'] ?: '—') ?></td>
            <td><?= $s['profile_completed'] ? '<span class="badge-pill badge-green">Complete</span>' : '<span class="badge-pill badge-red">Incomplete</span>' ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$recentStudents): ?><tr><td colspan="3" class="text-muted">No students yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <h3>Recent Project Uploads</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Student</th><th>Course</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($recentProjects as $p): ?>
          <tr>
            <td><?= htmlspecialchars($p['full_name']) ?> (<?= htmlspecialchars($p['matric_no']) ?>)</td>
            <td><?= htmlspecialchars($p['course_code']) ?></td>
            <td><?= $p['is_duplicate'] ? '<span class="badge-pill badge-red">Duplicate</span>' : '<span class="badge-pill badge-green">Unique</span>' ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$recentProjects): ?><tr><td colspan="3" class="text-muted">No project uploads yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
