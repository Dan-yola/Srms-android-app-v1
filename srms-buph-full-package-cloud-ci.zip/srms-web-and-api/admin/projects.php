<?php
$pageTitle = 'Student Projects';
require_once __DIR__ . '/includes/header.php';

$filter = $_GET['filter'] ?? 'all';
$sql = "SELECT p.*, s.full_name, s.matric_no, c.course_code
        FROM projects p
        JOIN students s ON s.id = p.student_id
        JOIN courses c ON c.id = p.course_id";
if ($filter === 'duplicate') {
    $sql .= " WHERE p.is_duplicate = 1";
}
$sql .= " ORDER BY p.uploaded_at DESC";
$projects = $pdo->query($sql)->fetchAll();

$dupCount = $pdo->query("SELECT COUNT(*) c FROM projects WHERE is_duplicate = 1")->fetch()['c'];
?>

<div class="flex-between">
  <h2>Student Project Submissions</h2>
</div>

<div class="card">
  <div class="flex gap-10" style="margin-bottom:16px;">
    <a class="btn btn-sm <?= $filter === 'all' ? 'btn-primary' : 'btn-outline' ?>" href="?filter=all">All Submissions</a>
    <a class="btn btn-sm <?= $filter === 'duplicate' ? 'btn-danger' : 'btn-outline' ?>" href="?filter=duplicate">⚠ Flagged Duplicates (<?= $dupCount ?>)</a>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Student</th><th>Matric No</th><th>Course</th><th>Title</th><th>Uploaded</th><th>Status</th><th>File</th></tr></thead>
      <tbody>
      <?php foreach ($projects as $p): ?>
        <tr>
          <td><?= htmlspecialchars($p['full_name']) ?></td>
          <td><?= htmlspecialchars($p['matric_no']) ?></td>
          <td><?= htmlspecialchars($p['course_code']) ?></td>
          <td><?= htmlspecialchars($p['title']) ?></td>
          <td><?= htmlspecialchars(date('d M Y, h:i A', strtotime($p['uploaded_at']))) ?></td>
          <td>
            <?php if ($p['is_duplicate']): ?>
              <span class="badge-pill badge-red" title="Matches an earlier submission">⚠ Duplicate</span>
            <?php else: ?>
              <span class="badge-pill badge-green">Unique</span>
            <?php endif; ?>
          </td>
          <td><a href="../uploads/projects/<?= htmlspecialchars($p['file_path']) ?>" target="_blank">View</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$projects): ?><tr><td colspan="7" class="text-muted">No project submissions found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
