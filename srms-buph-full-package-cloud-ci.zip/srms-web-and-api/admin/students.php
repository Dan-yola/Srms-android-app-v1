<?php
$pageTitle = 'Students';
require_once __DIR__ . '/includes/header.php';

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare(
        "SELECT * FROM students WHERE full_name LIKE ? OR matric_no LIKE ? OR email LIKE ? ORDER BY created_at DESC"
    );
    $like = "%$search%";
    $stmt->execute([$like, $like, $like]);
} else {
    $stmt = $pdo->query("SELECT * FROM students ORDER BY created_at DESC");
}
$students = $stmt->fetchAll();
?>

<div class="flex-between">
  <h2>All Students</h2>
</div>

<div class="card">
  <form method="GET" class="flex gap-10" style="margin-bottom: 18px;">
    <input type="text" name="q" placeholder="Search by name, matric no, or email" value="<?= htmlspecialchars($search) ?>">
    <button class="btn btn-primary" type="submit">Search</button>
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Matric No</th><th>Name</th><th>Department</th><th>Level</th><th>Profile</th><th>Status</th><th>Action</th></tr>
      </thead>
      <tbody>
      <?php foreach ($students as $s): ?>
        <tr>
          <td><?= htmlspecialchars($s['matric_no']) ?></td>
          <td><?= htmlspecialchars($s['full_name'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['department'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['level'] ?: '—') ?></td>
          <td><?= $s['profile_completed'] ? '<span class="badge-pill badge-green">Complete</span>' : '<span class="badge-pill badge-red">Incomplete</span>' ?></td>
          <td><span class="badge-pill <?= $s['status'] === 'active' ? 'badge-green' : 'badge-red' ?>"><?= ucfirst($s['status']) ?></span></td>
          <td><a class="btn btn-sm btn-outline" href="student_view.php?id=<?= $s['id'] ?>">View</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$students): ?><tr><td colspan="7" class="text-muted">No students found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
