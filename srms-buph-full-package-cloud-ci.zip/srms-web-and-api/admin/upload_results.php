<?php
$pageTitle = 'Upload Results';
require_once __DIR__ . '/includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_result'])) {
    $studentId = (int) $_POST['student_id'];
    $courseId  = (int) $_POST['course_id'];
    $session   = clean($_POST['session']);
    $semester  = clean($_POST['semester']);
    $ca        = (float) $_POST['ca_score'];
    $exam      = (float) $_POST['exam_score'];
    $total     = $ca + $exam;
    $grade     = grade_from_score($total);

    $stmt = $pdo->prepare(
        "INSERT INTO results (student_id, course_id, session, semester, ca_score, exam_score, total_score, grade, uploaded_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE ca_score = VALUES(ca_score), exam_score = VALUES(exam_score),
         total_score = VALUES(total_score), grade = VALUES(grade), uploaded_by = VALUES(uploaded_by)"
    );
    $stmt->execute([$studentId, $courseId, $session, $semester, $ca, $exam, $total, $grade, $_SESSION['admin_id']]);
    set_flash('success', 'Result saved successfully.');
    redirect('upload_results.php');
}

$students = $pdo->query("SELECT id, matric_no, full_name FROM students ORDER BY full_name")->fetchAll();
$courses  = $pdo->query("SELECT id, course_code, course_title, level, semester, session FROM courses ORDER BY course_code")->fetchAll();

$recent = $pdo->query(
    "SELECT r.*, s.matric_no, s.full_name, c.course_code FROM results r
     JOIN students s ON s.id = r.student_id
     JOIN courses c ON c.id = r.course_id
     ORDER BY r.uploaded_at DESC LIMIT 15"
)->fetchAll();
?>

<div class="flex-between"><h2>Upload / Enter Results</h2></div>

<div class="grid cols-2">
  <div class="card">
    <h3>Enter a Result</h3>
    <form method="POST">
      <input type="hidden" name="upload_result" value="1">
      <div class="form-group">
        <label>Student</label>
        <select name="student_id" required>
          <option value="">-- Select Student --</option>
          <?php foreach ($students as $s): ?>
            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['matric_no'] . ' — ' . ($s['full_name'] ?: 'No name')) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Course</label>
        <select name="course_id" id="course_select" required onchange="fillSemSession(this)">
          <option value="">-- Select Course --</option>
          <?php foreach ($courses as $c): ?>
            <option value="<?= $c['id'] ?>" data-session="<?= htmlspecialchars($c['session']) ?>" data-semester="<?= htmlspecialchars($c['semester']) ?>">
              <?= htmlspecialchars($c['course_code'] . ' (' . $c['level'] . ', ' . $c['semester'] . ' Sem, ' . $c['session'] . ')') ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="grid cols-2">
        <div class="form-group">
          <label>Session</label>
          <input type="text" name="session" id="session_field" required>
        </div>
        <div class="form-group">
          <label>Semester</label>
          <select name="semester" id="semester_field" required>
            <option value="First">First</option>
            <option value="Second">Second</option>
          </select>
        </div>
      </div>
      <div class="grid cols-2">
        <div class="form-group">
          <label>CA Score (max 30)</label>
          <input type="number" step="0.01" name="ca_score" max="30" min="0" required>
        </div>
        <div class="form-group">
          <label>Exam Score (max 70)</label>
          <input type="number" step="0.01" name="exam_score" max="70" min="0" required>
        </div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Save Result</button>
    </form>
  </div>

  <div class="card">
    <h3>Recently Uploaded</h3>
    <div class="table-wrap" style="max-height: 480px; overflow-y:auto;">
      <table>
        <thead><tr><th>Student</th><th>Course</th><th>Total</th><th>Grade</th></tr></thead>
        <tbody>
        <?php foreach ($recent as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['matric_no']) ?></td>
            <td><?= htmlspecialchars($r['course_code']) ?></td>
            <td><?= htmlspecialchars($r['total_score']) ?></td>
            <td><span class="badge-pill badge-gold"><?= htmlspecialchars($r['grade']) ?></span></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$recent): ?><tr><td colspan="4" class="text-muted">No results uploaded yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function fillSemSession(sel) {
  const opt = sel.options[sel.selectedIndex];
  document.getElementById('session_field').value = opt.dataset.session || '';
  document.getElementById('semester_field').value = opt.dataset.semester || 'First';
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
