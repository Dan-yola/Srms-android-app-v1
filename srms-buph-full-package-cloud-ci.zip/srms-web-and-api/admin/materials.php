<?php
$pageTitle = 'Teaching Materials';
require_once __DIR__ . '/includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_material'])) {
    $courseId = (int) $_POST['course_id'];
    $title    = clean($_POST['title']);

    if (!empty($_FILES['material_file']['name'])) {
        $allowed = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'zip'];
        $ext = strtolower(pathinfo($_FILES['material_file']['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed)) {
            set_flash('error', 'Invalid file type. Allowed: ' . implode(', ', $allowed));
        } else {
            $newName = 'material_' . uniqid() . '.' . $ext;
            if (!is_dir(UPLOAD_MATERIALS_DIR)) mkdir(UPLOAD_MATERIALS_DIR, 0777, true);
            move_uploaded_file($_FILES['material_file']['tmp_name'], UPLOAD_MATERIALS_DIR . $newName);

            $stmt = $pdo->prepare(
                "INSERT INTO materials (course_id, title, file_path, uploaded_by) VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$courseId, $title, $newName, $_SESSION['admin_id']]);
            set_flash('success', 'Material uploaded successfully.');
        }
    } else {
        set_flash('error', 'Please choose a file to upload.');
    }
    redirect('materials.php');
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("SELECT file_path FROM materials WHERE id = ?");
    $stmt->execute([(int) $_GET['delete']]);
    $m = $stmt->fetch();
    if ($m) {
        @unlink(UPLOAD_MATERIALS_DIR . $m['file_path']);
        $pdo->prepare("DELETE FROM materials WHERE id = ?")->execute([(int) $_GET['delete']]);
        set_flash('success', 'Material deleted.');
    }
    redirect('materials.php');
}

$courses = $pdo->query("SELECT id, course_code, course_title FROM courses ORDER BY course_code")->fetchAll();
$materials = $pdo->query(
    "SELECT m.*, c.course_code FROM materials m JOIN courses c ON c.id = m.course_id ORDER BY m.uploaded_at DESC"
)->fetchAll();
?>

<div class="flex-between"><h2>Teaching Materials</h2></div>

<div class="grid cols-2">
  <div class="card">
    <h3>Upload New Material</h3>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="upload_material" value="1">
      <div class="form-group">
        <label>Course</label>
        <select name="course_id" required>
          <option value="">-- Select Course --</option>
          <?php foreach ($courses as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['course_code'] . ' — ' . $c['course_title']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" placeholder="e.g. Week 3 Lecture Note" required>
      </div>
      <div class="form-group">
        <label>File (PDF, Word, PPT, or ZIP)</label>
        <input type="file" name="material_file" id="mat_file" required>
        <div class="form-hint" data-file-preview="mat_file">No file chosen</div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Upload Material</button>
    </form>
  </div>

  <div class="card">
    <h3>Uploaded Materials (<?= count($materials) ?>)</h3>
    <div class="table-wrap" style="max-height: 480px; overflow-y:auto;">
      <table>
        <thead><tr><th>Course</th><th>Title</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($materials as $m): ?>
          <tr>
            <td><?= htmlspecialchars($m['course_code']) ?></td>
            <td><?= htmlspecialchars($m['title']) ?></td>
            <td>
              <a class="btn btn-sm btn-outline" href="../uploads/materials/<?= htmlspecialchars($m['file_path']) ?>" target="_blank">Download</a>
              <a class="btn btn-sm btn-danger" href="?delete=<?= $m['id'] ?>" onclick="return confirmAction('Delete this material?')">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$materials): ?><tr><td colspan="3" class="text-muted">No materials uploaded yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
