<?php
$pageTitle = 'Registration Window';
require_once __DIR__ . '/includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_window'])) {
    $session   = clean($_POST['session']);
    $semester  = clean($_POST['semester']);
    $level     = clean($_POST['level']);
    $openDate  = $_POST['open_date'];
    $closeDate = $_POST['close_date'];

    $stmt = $pdo->prepare(
        "INSERT INTO registration_settings (session, semester, level, open_date, close_date, is_open, created_by)
         VALUES (?, ?, ?, ?, ?, 1, ?)
         ON DUPLICATE KEY UPDATE open_date = VALUES(open_date), close_date = VALUES(close_date), is_open = 1"
    );
    $stmt->execute([$session, $semester, $level, $openDate, $closeDate, $_SESSION['admin_id']]);
    set_flash('success', "Registration window saved for $level — $semester Semester, $session.");
    redirect('registration_settings.php');
}

if (isset($_GET['close'])) {
    $pdo->prepare("UPDATE registration_settings SET is_open = 0 WHERE id = ?")->execute([(int) $_GET['close']]);
    set_flash('success', 'Registration window closed.');
    redirect('registration_settings.php');
}

if (isset($_GET['reopen'])) {
    $pdo->prepare("UPDATE registration_settings SET is_open = 1 WHERE id = ?")->execute([(int) $_GET['reopen']]);
    set_flash('success', 'Registration window reopened.');
    redirect('registration_settings.php');
}

$windows = $pdo->query("SELECT * FROM registration_settings ORDER BY session DESC, semester, level")->fetchAll();
?>

<div class="flex-between">
  <h2>Registration Window &amp; Countdown</h2>
</div>

<div class="grid cols-2">
  <div class="card">
    <h3>Set / Update Registration Window</h3>
    <p class="text-muted">Students can only register courses and generate a Remita reference while a window is open and the current time falls within it.</p>
    <form method="POST">
      <input type="hidden" name="save_window" value="1">
      <div class="form-group">
        <label>Session</label>
        <input type="text" name="session" placeholder="e.g. 2025/2026" required>
      </div>
      <div class="grid cols-2">
        <div class="form-group">
          <label>Semester</label>
          <select name="semester" required>
            <option value="First">First Semester</option>
            <option value="Second">Second Semester</option>
          </select>
        </div>
        <div class="form-group">
          <label>Level</label>
          <select name="level" required>
            <option value="ND1">ND1</option>
            <option value="ND2">ND2</option>
            <option value="HND1">HND1</option>
            <option value="HND2">HND2</option>
          </select>
        </div>
      </div>
      <div class="grid cols-2">
        <div class="form-group">
          <label>Opens On</label>
          <input type="datetime-local" name="open_date" required>
        </div>
        <div class="form-group">
          <label>Closes On</label>
          <input type="datetime-local" name="close_date" required>
        </div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Save Window</button>
    </form>
  </div>

  <div class="card">
    <h3>Existing Windows</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Session</th><th>Sem.</th><th>Level</th><th>Opens</th><th>Closes</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($windows as $w):
          $now = new DateTime();
          $open = new DateTime($w['open_date']);
          $close = new DateTime($w['close_date']);
          $live = $w['is_open'] && $now >= $open && $now <= $close;
        ?>
          <tr>
            <td><?= htmlspecialchars($w['session']) ?></td>
            <td><?= htmlspecialchars($w['semester']) ?></td>
            <td><?= htmlspecialchars($w['level']) ?></td>
            <td><?= htmlspecialchars(date('d M Y, h:i A', strtotime($w['open_date']))) ?></td>
            <td><?= htmlspecialchars(date('d M Y, h:i A', strtotime($w['close_date']))) ?></td>
            <td><?= $live ? '<span class="badge-pill badge-green">Open</span>' : '<span class="badge-pill badge-red">Closed</span>' ?></td>
            <td>
              <?php if ($w['is_open']): ?>
                <a class="btn btn-sm btn-danger" href="?close=<?= $w['id'] ?>">Close</a>
              <?php else: ?>
                <a class="btn btn-sm btn-primary" href="?reopen=<?= $w['id'] ?>">Reopen</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$windows): ?><tr><td colspan="7" class="text-muted">No windows configured yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
