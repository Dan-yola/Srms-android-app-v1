<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/functions.php';
require_admin();
$flash = get_flash();
$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — Admin' : 'Admin Panel' ?> | <?= htmlspecialchars(SCHOOL_SHORT) ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="topbar">
  <div class="container">
    <div class="brand">
      <div class="badge">BU</div>
      <div>
        <h1><?= htmlspecialchars(SCHOOL_NAME) ?></h1>
        <span>Admin Console</span>
      </div>
    </div>
    <nav>
      <span style="margin-right:18px; color:#eafaf1; font-size:14px;">👤 <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
      <a href="logout.php">Logout</a>
    </nav>
  </div>
</header>

<div class="app-shell">
  <aside class="sidebar">
    <a href="dashboard.php" class="<?= $current === 'dashboard.php' ? 'active' : '' ?>">🏠 Dashboard</a>
    <a href="students.php" class="<?= $current === 'students.php' || $current === 'student_view.php' ? 'active' : '' ?>">🎓 Students</a>
    <a href="courses.php" class="<?= $current === 'courses.php' ? 'active' : '' ?>">📚 Courses</a>
    <a href="registration_settings.php" class="<?= $current === 'registration_settings.php' ? 'active' : '' ?>">⏱ Registration Window</a>
    <a href="upload_results.php" class="<?= $current === 'upload_results.php' ? 'active' : '' ?>">📊 Upload Results</a>
    <a href="materials.php" class="<?= $current === 'materials.php' ? 'active' : '' ?>">📁 Teaching Materials</a>
    <a href="projects.php" class="<?= $current === 'projects.php' ? 'active' : '' ?>">🧪 Student Projects</a>
  </aside>
  <main class="content">
    <?php if ($flash): ?>
      <div class="alert alert-<?= $flash['type'] === 'error' ? 'error' : 'success' ?>"><?= htmlspecialchars($flash['message']) ?></div>
    <?php endif; ?>
