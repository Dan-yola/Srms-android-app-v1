<?php
/**
 * ONE-TIME SETUP SCRIPT
 * Visit this once in your browser: http://localhost/srms/setup.php
 * It creates the first admin account with a securely hashed password.
 * Delete this file (or it will refuse to run again) once you've used it.
 */
require_once 'config/db.php';

$lockFile = __DIR__ . '/setup.lock';
$done = false;
$error = '';

if (file_exists($lockFile)) {
    $done = true;
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $fullName = trim($_POST['full_name'] ?? '');
    $email    = trim($_POST['email'] ?? '');

    if (!$username || !$password || !$fullName) {
        $error = 'All fields except email are required.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $check = $pdo->prepare('SELECT id FROM admins WHERE username = ?');
        $check->execute([$username]);
        if ($check->fetch()) {
            $error = 'That username already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                'INSERT INTO admins (username, password, full_name, email) VALUES (?, ?, ?, ?)'
            );
            $stmt->execute([$username, $hash, $fullName, $email]);
            file_put_contents($lockFile, 'setup completed on ' . date('c'));
            $done = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SRMS Setup — <?= htmlspecialchars(SCHOOL_NAME) ?></title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="logo"><div class="badge">BU</div></div>
    <h2><?= htmlspecialchars(SCHOOL_NAME) ?></h2>
    <p class="subtitle">First-time system setup</p>

    <?php if ($done): ?>
      <div class="alert alert-success">
        Setup already completed. An admin account exists.
        For security, please delete <code>setup.php</code> and <code>setup.lock</code> from the server now.
      </div>
      <a class="btn btn-primary btn-block" href="admin/login.php">Go to Admin Login</a>
    <?php else: ?>
      <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <form method="POST">
        <div class="form-group">
          <label>Admin Username</label>
          <input type="text" name="username" required value="admin">
        </div>
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="full_name" required value="System Administrator">
        </div>
        <div class="form-group">
          <label>Email (optional)</label>
          <input type="email" name="email">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" required minlength="6">
        </div>
        <button class="btn btn-primary btn-block" type="submit">Create Admin Account</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
