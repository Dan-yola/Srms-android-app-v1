<?php require_once 'config/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(SCHOOL_NAME) ?> — Student Results Management System</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="topbar">
  <div class="container">
    <div class="brand">
      <div class="badge">BU</div>
      <div>
        <h1><?= htmlspecialchars(SCHOOL_NAME) ?></h1>
        <span>Student Results Management System</span>
      </div>
    </div>
    <nav>
      <a href="student/login.php">Student Login</a>
      <a href="student/register.php">Student Sign Up</a>
      <a href="admin/login.php">Admin</a>
    </nav>
  </div>
</header>

<section class="landing-hero">
  <div class="container">
    <h2>Manage Courses, Registration &amp; Results — All in One Place</h2>
    <p>A secure portal for students of <?= htmlspecialchars(SCHOOL_NAME) ?> to register courses, submit projects, and access results and course materials online.</p>
    <div class="hero-actions">
      <a href="student/register.php" class="btn btn-accent">Create Student Account</a>
      <a href="student/login.php" class="btn btn-outline" style="background:#fff;">Student Login</a>
    </div>
  </div>
</section>

<section class="feature-strip">
  <div class="container grid cols-3">
    <div class="feature-card">
      <h3>📝 Course Registration</h3>
      <p class="text-muted">Register for semester courses within the official registration window, with a live countdown and a Remita-style payment reference.</p>
    </div>
    <div class="feature-card">
      <h3>📊 Results &amp; Materials</h3>
      <p class="text-muted">View and download your results per session/semester, and access lecture materials uploaded by your department.</p>
    </div>
    <div class="feature-card">
      <h3>📁 Project Uploads</h3>
      <p class="text-muted">Submit course projects online. The system automatically checks for duplicate submissions.</p>
    </div>
  </div>
</section>

<footer class="site-footer">
  &copy; <?= date('Y') ?> <?= htmlspecialchars(SCHOOL_NAME) ?>. All rights reserved.
</footer>

</body>
</html>
