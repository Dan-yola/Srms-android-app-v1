<?php
/**
 * Database connection (PDO + MySQL / XAMPP defaults)
 * Adjust $host/$db/$user/$pass if your XAMPP MySQL setup differs.
 */
$host = 'localhost';
$db   = 'srms_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
}

// ---- School / system-wide constants ----
define('SCHOOL_NAME', 'BINYAMINU USMAN POLYTECHNIC, HADEJIA');
define('SCHOOL_SHORT', 'BUPH');
// The school's designated collection account (Access Bank, 1646445316).
// This is used in place of a live Remita merchant account: students "pay"
// school/registration fees into this account and the system generates a
// Remita-style reference (RRR) before they can register courses. This is
// a simulated/mock Remita flow for a school project — no real payment
// gateway is contacted, so no money actually moves through this code.
define('REMITA_SCHOOL_ACCOUNT', '1646445316');

define('UPLOAD_RESULTS_DIR',   __DIR__ . '/../uploads/results/');
define('UPLOAD_MATERIALS_DIR', __DIR__ . '/../uploads/materials/');
define('UPLOAD_PROJECTS_DIR',  __DIR__ . '/../uploads/projects/');
