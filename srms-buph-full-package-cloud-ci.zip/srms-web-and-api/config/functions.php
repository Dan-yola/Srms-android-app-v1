<?php
/**
 * Shared helper functions.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function clean($str) {
    return htmlspecialchars(trim($str ?? ''), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function require_admin() {
    if (empty($_SESSION['admin_id'])) {
        redirect('login.php');
    }
}

function require_student_login() {
    if (empty($_SESSION['student_id'])) {
        redirect('login.php');
    }
}

// A logged-in student must have a completed profile before they can use
// anything beyond the profile page itself.
function require_completed_profile() {
    require_student_login();
    if (empty($_SESSION['profile_completed'])) {
        set_flash('error', 'Please complete your profile before continuing.');
        redirect('profile.php');
    }
}

/**
 * Checks whether course registration is currently open for a given
 * session + semester + level, based on the admin-configured countdown
 * window. Returns an associative array with status + window details.
 */
function get_registration_window(PDO $pdo, $session, $semester, $level) {
    $stmt = $pdo->prepare(
        "SELECT * FROM registration_settings
         WHERE session = ? AND semester = ? AND level = ? LIMIT 1"
    );
    $stmt->execute([$session, $semester, $level]);
    $row = $stmt->fetch();

    if (!$row) {
        return ['exists' => false, 'open' => false];
    }

    $now   = new DateTime();
    $open  = new DateTime($row['open_date']);
    $close = new DateTime($row['close_date']);
    $isOpen = $row['is_open'] && $now >= $open && $now <= $close;

    return [
        'exists'    => true,
        'open'      => $isOpen,
        'row'       => $row,
        'open_date' => $row['open_date'],
        'close_date'=> $row['close_date'],
    ];
}

// Generates a mock Remita Retrieval Reference number (RRR)
function generate_rrr() {
    return date('ymd') . rand(1000000, 9999999);
}

function grade_from_score($score) {
    $score = (float) $score;
    if ($score >= 70) return 'A';
    if ($score >= 60) return 'B';
    if ($score >= 50) return 'C';
    if ($score >= 45) return 'D';
    if ($score >= 40) return 'E';
    return 'F';
}
