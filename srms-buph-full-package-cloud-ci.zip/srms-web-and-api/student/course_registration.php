<?php
$pageTitle = 'Course Registration';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_completed_profile();

$sid = $_SESSION['student_id'];
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$sid]);
$student = $stmt->fetch();

// Which windows exist for this student's level?
$winStmt = $pdo->prepare("SELECT * FROM registration_settings WHERE level = ? ORDER BY session DESC, semester");
$winStmt->execute([$student['level']]);
$windows = $winStmt->fetchAll();

$selectedSession  = $_POST['session'] ?? $_GET['session'] ?? ($windows[0]['session'] ?? '');
$selectedSemester = $_POST['semester'] ?? $_GET['semester'] ?? ($windows[0]['semester'] ?? 'First');

$window = get_registration_window($pdo, $selectedSession, $selectedSemester, $student['level']);

// Handle registration submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_register'])) {
    if (!$window['exists'] || !$window['open']) {
        set_flash('error', 'Registration is not currently open for this session/semester. You cannot generate a Remita reference or register yet.');
        redirect('course_registration.php?session=' . urlencode($selectedSession) . '&semester=' . urlencode($selectedSemester));
    }

    $courseIds = $_POST['course_ids'] ?? [];
    if (!$courseIds) {
        set_flash('error', 'Please select at least one course to register.');
        redirect('course_registration.php?session=' . urlencode($selectedSession) . '&semester=' . urlencode($selectedSemester));
    }

    // One Remita reference covers this whole registration batch, using the
    // school's designated collection account.
    $rrr = generate_rrr();
    $inserted = 0;

    foreach ($courseIds as $courseId) {
        $courseId = (int) $courseId;
        try {
            $ins = $pdo->prepare(
                "INSERT INTO course_registrations (student_id, course_id, session, semester, remita_rrr, remita_account, payment_status)
                 VALUES (?, ?, ?, ?, ?, ?, 'confirmed')"
            );
            $ins->execute([$sid, $courseId, $selectedSession, $selectedSemester, $rrr, REMITA_SCHOOL_ACCOUNT]);
            $inserted++;
        } catch (PDOException $e) {
            // Already registered for this course this session/semester — skip silently
        }
    }

    if ($inserted > 0) {
        set_flash('success', "Registration successful! $inserted course(s) registered. Your Remita Reference (RRR) is $rrr.");
    } else {
        set_flash('error', 'You are already registered for the selected course(s).');
    }
    redirect('course_registration.php?session=' . urlencode($selectedSession) . '&semester=' . urlencode($selectedSemester));
}

// Courses available to this student for the chosen session/semester/level
$courseStmt = $pdo->prepare(
    "SELECT * FROM courses WHERE level = ? AND semester = ? AND session = ?
     AND (department = ? OR department = 'General') ORDER BY course_code"
);
$courseStmt->execute([$student['level'], $selectedSemester, $selectedSession, $student['department']]);
$availableCourses = $courseStmt->fetchAll();

// Courses already registered by this student for this session/semester
$regStmt = $pdo->prepare(
    "SELECT course_id, remita_rrr FROM course_registrations WHERE student_id = ? AND session = ? AND semester = ?"
);
$regStmt->execute([$sid, $selectedSession, $selectedSemester]);
$registeredRows = $regStmt->fetchAll();
$registeredIds = array_column($registeredRows, 'course_id');
$currentRrr = $registeredRows[0]['remita_rrr'] ?? null;

require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between"><h2>Course Registration</h2></div>

<div class="card">
  <form method="GET" class="grid cols-2">
    <div class="form-group">
      <label>Session</label>
      <select name="session" onchange="this.form.submit()">
        <?php $sessions = array_unique(array_column($windows, 'session')); ?>
        <?php foreach ($sessions as $s): ?>
          <option value="<?= htmlspecialchars($s) ?>" <?= $s === $selectedSession ? 'selected' : '' ?>><?= htmlspecialchars($s) ?></option>
        <?php endforeach; ?>
        <?php if (!$sessions): ?><option value="">No sessions configured</option><?php endif; ?>
      </select>
    </div>
    <div class="form-group">
      <label>Semester</label>
      <select name="semester" onchange="this.form.submit()">
        <option value="First" <?= $selectedSemester === 'First' ? 'selected' : '' ?>>First Semester</option>
        <option value="Second" <?= $selectedSemester === 'Second' ? 'selected' : '' ?>>Second Semester</option>
      </select>
    </div>
  </form>
</div>

<?php if (!$window['exists']): ?>
  <div class="alert alert-error">No registration window has been configured yet for <?= htmlspecialchars($student['level']) ?> — <?= htmlspecialchars($selectedSemester) ?> Semester, <?= htmlspecialchars($selectedSession) ?>. Please check back later.</div>
<?php else: ?>
  <div class="card text-center">
    <h3 id="cd-status">Registration Status</h3>
    <div id="reg-countdown" data-open="<?= htmlspecialchars(str_replace(' ', 'T', $window['open_date'])) ?>" data-close="<?= htmlspecialchars(str_replace(' ', 'T', $window['close_date'])) ?>">
      <div class="countdown-box">
        <div class="unit"><span class="val" id="cd-days">00</span><span class="lbl">DAYS</span></div>
        <div class="unit"><span class="val" id="cd-hours">00</span><span class="lbl">HOURS</span></div>
        <div class="unit"><span class="val" id="cd-mins">00</span><span class="lbl">MINS</span></div>
        <div class="unit"><span class="val" id="cd-secs">00</span><span class="lbl">SECS</span></div>
      </div>
    </div>
    <p class="text-muted">Window: <?= htmlspecialchars(date('d M Y h:i A', strtotime($window['open_date']))) ?> &rarr; <?= htmlspecialchars(date('d M Y h:i A', strtotime($window['close_date']))) ?></p>
    <?php if ($window['open']): ?>
      <span class="badge-pill badge-green">Registration is OPEN</span>
    <?php else: ?>
      <span class="badge-pill badge-red">Registration is CLOSED</span>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="flex-between">
      <h3>Available Courses — <?= htmlspecialchars($student['level']) ?>, <?= htmlspecialchars($selectedSemester) ?> Semester</h3>
      <?php if ($currentRrr): ?><span class="badge-pill badge-gold">Your RRR: <?= htmlspecialchars($currentRrr) ?></span><?php endif; ?>
    </div>

    <div class="alert alert-info">
      Registration fees for this exercise are collected, Remita-style, into the school's designated
      <strong>Access Bank</strong> account: <strong><?= htmlspecialchars(REMITA_SCHOOL_ACCOUNT) ?></strong>.
      Submitting the form below generates your Remita Reference (RRR) automatically against this account.
    </div>

    <?php if (!$window['open']): ?>
      <p class="text-muted">You cannot select or register courses because the registration window is not currently open.</p>
    <?php elseif (!$availableCourses): ?>
      <p class="text-muted">No courses have been configured yet for your department/level/semester.</p>
    <?php else: ?>
      <form method="POST">
        <input type="hidden" name="do_register" value="1">
        <input type="hidden" name="session" value="<?= htmlspecialchars($selectedSession) ?>">
        <input type="hidden" name="semester" value="<?= htmlspecialchars($selectedSemester) ?>">
        <div class="table-wrap">
          <table>
            <thead><tr><th></th><th>Code</th><th>Title</th><th>Unit</th></tr></thead>
            <tbody>
            <?php foreach ($availableCourses as $c): $already = in_array($c['id'], $registeredIds); ?>
              <tr>
                <td>
                  <input type="checkbox" name="course_ids[]" value="<?= $c['id'] ?>" <?= $already ? 'checked disabled' : '' ?>>
                </td>
                <td><?= htmlspecialchars($c['course_code']) ?></td>
                <td><?= htmlspecialchars($c['course_title']) ?></td>
                <td><?= (int) $c['unit'] ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <button class="btn btn-primary" style="margin-top:16px;" type="submit" onclick="return confirmAction('Generate your Remita reference and submit this registration?')">
          Generate Remita Reference &amp; Register
        </button>
      </form>
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
