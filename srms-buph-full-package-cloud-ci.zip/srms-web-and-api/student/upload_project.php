<?php
$pageTitle = 'Upload Project';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_completed_profile();

$sid = $_SESSION['student_id'];

// Only show courses the student is actually registered for
$courseStmt = $pdo->prepare(
    "SELECT DISTINCT c.* FROM courses c
     JOIN course_registrations cr ON cr.course_id = c.id
     WHERE cr.student_id = ? ORDER BY c.course_code"
);
$courseStmt->execute([$sid]);
$myCourses = $courseStmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_project'])) {
    $courseId = (int) $_POST['course_id'];
    $title    = clean($_POST['title']);

    if (empty($_FILES['project_file']['name'])) {
        set_flash('error', 'Please choose a file to upload.');
        redirect('upload_project.php');
    }

    $allowed = ['pdf', 'doc', 'docx', 'zip', 'rar'];
    $ext = strtolower(pathinfo($_FILES['project_file']['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) {
        set_flash('error', 'Invalid file type. Allowed: ' . implode(', ', $allowed));
        redirect('upload_project.php');
    }

    $tmpPath = $_FILES['project_file']['tmp_name'];
    $fileHash = hash_file('sha256', $tmpPath);

    // ---- Duplicate check: same file content already submitted (by this
    // student or by anyone else) for this course ----
    $dupStmt = $pdo->prepare(
        "SELECT p.id, s.full_name, s.matric_no FROM projects p
         JOIN students s ON s.id = p.student_id
         WHERE p.course_id = ? AND p.file_hash = ? LIMIT 1"
    );
    $dupStmt->execute([$courseId, $fileHash]);
    $duplicateOf = $dupStmt->fetch();

    $newName = 'project_' . $sid . '_' . uniqid() . '.' . $ext;
    if (!is_dir(UPLOAD_PROJECTS_DIR)) mkdir(UPLOAD_PROJECTS_DIR, 0777, true);
    move_uploaded_file($tmpPath, UPLOAD_PROJECTS_DIR . $newName);

    $isDuplicate = $duplicateOf ? 1 : 0;
    $duplicateId = $duplicateOf['id'] ?? null;

    $stmt = $pdo->prepare(
        "INSERT INTO projects (student_id, course_id, title, file_path, file_hash, is_duplicate, duplicate_of)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([$sid, $courseId, $title, $newName, $fileHash, $isDuplicate, $duplicateId]);

    if ($isDuplicate) {
        set_flash('error', "Warning: this file appears to be a duplicate of a project already submitted by {$duplicateOf['full_name']} ({$duplicateOf['matric_no']}). Your submission was recorded and flagged for admin review.");
    } else {
        set_flash('success', 'Project uploaded successfully.');
    }
    redirect('upload_project.php');
}

$myProjects = $pdo->prepare(
    "SELECT p.*, c.course_code FROM projects p JOIN courses c ON c.id = p.course_id
     WHERE p.student_id = ? ORDER BY p.uploaded_at DESC"
);
$myProjects->execute([$sid]);
$myProjects = $myProjects->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between"><h2>Upload Project</h2></div>

<div class="grid cols-2">
  <div class="card">
    <h3>Submit a Project</h3>
    <?php if (!$myCourses): ?>
      <p class="text-muted">You need to register for a course before you can upload a project.</p>
    <?php else: ?>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="upload_project" value="1">
        <div class="form-group">
          <label>Course</label>
          <select name="course_id" required>
            <?php foreach ($myCourses as $c): ?>
              <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['course_code'] . ' — ' . $c['course_title']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Project Title</label>
          <input type="text" name="title" required>
        </div>
        <div class="form-group">
          <label>Project File (PDF, Word, ZIP, RAR)</label>
          <input type="file" name="project_file" id="proj_file" required>
          <div class="form-hint" data-file-preview="proj_file">No file chosen</div>
          <div class="form-hint">Your file is automatically checked against previous submissions for the same course to detect duplicates.</div>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Upload Project</button>
      </form>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3>My Submissions</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Course</th><th>Title</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($myProjects as $p): ?>
          <tr>
            <td><?= htmlspecialchars($p['course_code']) ?></td>
            <td><?= htmlspecialchars($p['title']) ?></td>
            <td><?= $p['is_duplicate'] ? '<span class="badge-pill badge-red">Flagged Duplicate</span>' : '<span class="badge-pill badge-green">Received</span>' ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$myProjects): ?><tr><td colspan="3" class="text-muted">No submissions yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
