<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$sid = $_SESSION['student_id'];

$regCount = $pdo->prepare("SELECT COUNT(*) c FROM course_registrations WHERE student_id = ?");
$regCount->execute([$sid]);
$regCount = $regCount->fetch()['c'];

$resultCount = $pdo->prepare("SELECT COUNT(*) c FROM results WHERE student_id = ?");
$resultCount->execute([$sid]);
$resultCount = $resultCount->fetch()['c'];

$projectCount = $pdo->prepare("SELECT COUNT(*) c FROM projects WHERE student_id = ?");
$projectCount->execute([$sid]);
$projectCount = $projectCount->fetch()['c'];

$recentRegs = $pdo->prepare(
    "SELECT cr.*, c.course_code, c.course_title FROM course_registrations cr
     JOIN courses c ON c.id = cr.course_id WHERE cr.student_id = ? ORDER BY cr.registered_at DESC LIMIT 5"
);
$recentRegs->execute([$sid]);
$recentRegs = $recentRegs->fetchAll();
?>

<h2>Welcome, <?= htmlspecialchars($loggedInStudent['full_name'] ?: $loggedInStudent['matric_no']) ?> 👋</h2>

<div class="grid cols-3" style="margin-bottom: 24px;">
  <div class="stat-card"><div class="label">Registered Courses</div><div class="num"><?= $regCount ?></div></div>
  <div class="stat-card"><div class="label">Results Available</div><div class="num"><?= $resultCount ?></div></div>
  <div class="stat-card"><div class="label">Projects Submitted</div><div class="num"><?= $projectCount ?></div></div>
</div>

<div class="grid cols-2">
  <div class="card">
    <h3>Recent Course Registrations</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Course</th><th>Session</th><th>Semester</th></tr></thead>
        <tbody>
        <?php foreach ($recentRegs as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['course_code']) ?></td>
            <td><?= htmlspecialchars($r['session']) ?></td>
            <td><?= htmlspecialchars($r['semester']) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$recentRegs): ?><tr><td colspan="3" class="text-muted">No registrations yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <h3>Quick Links</h3>
    <div class="flex gap-10" style="flex-wrap: wrap;">
      <a class="btn btn-primary" href="course_registration.php">Register Courses</a>
      <a class="btn btn-outline" href="upload_project.php">Upload Project</a>
      <a class="btn btn-outline" href="results.php">View Results</a>
      <a class="btn btn-outline" href="materials.php">Course Materials</a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
