<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

if (!empty($_SESSION['student_id'])) {
    redirect('dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matric   = strtoupper(trim($_POST['matric_no'] ?? ''));
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM students WHERE matric_no = ?");
    $stmt->execute([$matric]);
    $student = $stmt->fetch();

    if (!$student || !password_verify($password, $student['password'])) {
        $error = 'Invalid matric number or password.';
    } elseif ($student['status'] === 'suspended') {
        $error = 'Your account has been suspended. Please contact the school administration.';
    } else {
        $_SESSION['student_id'] = $student['id'];
        $_SESSION['profile_completed'] = (bool) $student['profile_completed'];

        if (!$student['profile_completed']) {
            set_flash('info', 'Please complete your profile before continuing.');
            redirect('profile.php');
        }
        redirect('dashboard.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Login | <?= htmlspecialchars(SCHOOL_SHORT) ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="logo"><div class="badge">BU</div></div>
    <h2>Student Login</h2>
    <p class="subtitle"><?= htmlspecialchars(SCHOOL_NAME) ?></p>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Matriculation Number</label>
        <input type="text" name="matric_no" required autofocus>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Login</button>
    </form>
    <div class="auth-links">
      Don't have an account? <a href="register.php">Sign up</a><br>
      <a href="../index.php">&larr; Back to home</a>
    </div>
  </div>
</div>
</body>
</html>
