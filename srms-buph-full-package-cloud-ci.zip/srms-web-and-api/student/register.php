<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

if (!empty($_SESSION['student_id'])) {
    redirect('dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matric   = strtoupper(trim($_POST['matric_no'] ?? ''));
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!$matric || !$email || !$password) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $check = $pdo->prepare("SELECT id FROM students WHERE matric_no = ? OR email = ?");
        $check->execute([$matric, $email]);
        if ($check->fetch()) {
            $error = 'An account with this matric number or email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                "INSERT INTO students (matric_no, email, password, profile_completed) VALUES (?, ?, ?, 0)"
            );
            $stmt->execute([$matric, $email, $hash]);

            $_SESSION['student_id'] = $pdo->lastInsertId();
            $_SESSION['profile_completed'] = false;
            set_flash('success', 'Account created! Please complete your profile to continue.');
            redirect('profile.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Sign Up | <?= htmlspecialchars(SCHOOL_SHORT) ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="logo"><div class="badge">BU</div></div>
    <h2>Create Student Account</h2>
    <p class="subtitle"><?= htmlspecialchars(SCHOOL_NAME) ?></p>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Matriculation Number</label>
        <input type="text" name="matric_no" placeholder="e.g. BUP/CSC/23/1234" required autofocus>
      </div>
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" required>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required minlength="6">
      </div>
      <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="confirm_password" required minlength="6">
      </div>
      <button class="btn btn-primary btn-block" type="submit">Create Account</button>
    </form>
    <div class="auth-links">
      Already have an account? <a href="login.php">Login here</a><br>
      <a href="../index.php">&larr; Back to home</a>
    </div>
  </div>
</div>
</body>
</html>
