<?php
$pageTitle = 'My Results';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_completed_profile();

$sid = $_SESSION['student_id'];
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$sid]);
$student = $stmt->fetch();

$sessions = $pdo->prepare("SELECT DISTINCT session, semester FROM results WHERE student_id = ? ORDER BY session DESC, semester");
$sessions->execute([$sid]);
$sessions = $sessions->fetchAll();

$selSession  = $_GET['session'] ?? ($sessions[0]['session'] ?? '');
$selSemester = $_GET['semester'] ?? ($sessions[0]['semester'] ?? 'First');

$results = [];
$totalUnits = 0; $totalPoints = 0;
if ($selSession) {
    $resStmt = $pdo->prepare(
        "SELECT r.*, c.course_code, c.course_title, c.unit FROM results r
         JOIN courses c ON c.id = r.course_id
         WHERE r.student_id = ? AND r.session = ? AND r.semester = ?
         ORDER BY c.course_code"
    );
    $resStmt->execute([$sid, $selSession, $selSemester]);
    $results = $resStmt->fetchAll();

    $gradePoints = ['A' => 5, 'B' => 4, 'C' => 3, 'D' => 2, 'E' => 1, 'F' => 0];
    foreach ($results as $r) {
        $totalUnits += $r['unit'];
        $totalPoints += $r['unit'] * ($gradePoints[$r['grade']] ?? 0);
    }
}
$gpa = $totalUnits > 0 ? round($totalPoints / $totalUnits, 2) : 0;

require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between"><h2>My Results</h2></div>

<div class="card no-print">
  <form method="GET" class="grid cols-2">
    <div class="form-group">
      <label>Session / Semester</label>
      <select name="combo" onchange="location.href='results.php?session='+this.value.split('|')[0]+'&semester='+this.value.split('|')[1]">
        <?php foreach ($sessions as $s): ?>
          <option value="<?= htmlspecialchars($s['session']) ?>|<?= htmlspecialchars($s['semester']) ?>"
            <?= ($s['session'] === $selSession && $s['semester'] === $selSemester) ? 'selected' : '' ?>>
            <?= htmlspecialchars($s['session'] . ' — ' . $s['semester'] . ' Semester') ?>
          </option>
        <?php endforeach; ?>
        <?php if (!$sessions): ?><option value="">No results available yet</option><?php endif; ?>
      </select>
    </div>
    <div class="form-group" style="align-self:end;">
      <?php if ($results): ?>
        <button type="button" class="btn btn-accent btn-block" onclick="window.print()">⬇ Download / Print Result</button>
      <?php endif; ?>
    </div>
  </form>
</div>

<div class="card" id="printable-result">
  <div class="text-center" style="margin-bottom:18px;">
    <h3 class="mb-0"><?= htmlspecialchars(SCHOOL_NAME) ?></h3>
    <p class="text-muted mb-0">Official Result Slip</p>
  </div>

  <div class="grid cols-2" style="margin-bottom:18px;">
    <div>
      <p><strong>Name:</strong> <?= htmlspecialchars($student['full_name']) ?></p>
      <p><strong>Matric No:</strong> <?= htmlspecialchars($student['matric_no']) ?></p>
    </div>
    <div>
      <p><strong>Department:</strong> <?= htmlspecialchars($student['department']) ?></p>
      <p><strong>Session / Semester:</strong> <?= htmlspecialchars($selSession . ' — ' . $selSemester . ' Semester') ?></p>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Code</th><th>Title</th><th>Unit</th><th>CA</th><th>Exam</th><th>Total</th><th>Grade</th></tr></thead>
      <tbody>
      <?php foreach ($results as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['course_code']) ?></td>
          <td><?= htmlspecialchars($r['course_title']) ?></td>
          <td><?= (int) $r['unit'] ?></td>
          <td><?= htmlspecialchars($r['ca_score']) ?></td>
          <td><?= htmlspecialchars($r['exam_score']) ?></td>
          <td><?= htmlspecialchars($r['total_score']) ?></td>
          <td><span class="badge-pill badge-gold"><?= htmlspecialchars($r['grade']) ?></span></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$results): ?><tr><td colspan="7" class="text-muted">No results found for this session/semester.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($results): ?>
    <p style="margin-top:16px;"><strong>Total Units:</strong> <?= $totalUnits ?> &nbsp;|&nbsp; <strong>GPA:</strong> <?= $gpa ?></p>
  <?php endif; ?>
</div>

<style>
@media print {
  .topbar, .sidebar, .no-print, footer { display: none !important; }
  .content { padding: 0 !important; }
  body { background: #fff; }
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
