<?php
$pageTitle = 'My Profile';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_student_login();

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$_SESSION['student_id']]);
$student = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = clean($_POST['full_name']);
    $phone    = clean($_POST['phone']);
    $dept     = clean($_POST['department']);
    $level    = clean($_POST['level']);

    $photoName = $student['passport_photo'];
    if (!empty($_FILES['passport_photo']['name'])) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $ext = strtolower(pathinfo($_FILES['passport_photo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $photoDir = __DIR__ . '/../uploads/profile_photos/';
            if (!is_dir($photoDir)) mkdir($photoDir, 0777, true);
            $photoName = 'photo_' . $student['id'] . '_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['passport_photo']['tmp_name'], $photoDir . $photoName);
        }
    }

    if (!$fullName || !$phone || !$dept || !$level) {
        set_flash('error', 'Please fill in all required fields.');
    } else {
        $stmt = $pdo->prepare(
            "UPDATE students SET full_name = ?, phone = ?, department = ?, level = ?, passport_photo = ?, profile_completed = 1 WHERE id = ?"
        );
        $stmt->execute([$fullName, $phone, $dept, $level, $photoName, $student['id']]);
        $_SESSION['profile_completed'] = true;
        set_flash('success', 'Profile saved successfully.');
        redirect('dashboard.php');
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between"><h2>My Profile</h2></div>

<div class="card" style="max-width: 640px;">
  <?php if (!$student['profile_completed']): ?>
    <div class="alert alert-info">This is your first login — please complete your profile to unlock course registration, results, and materials.</div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data">
    <div class="grid cols-2">
      <div class="form-group">
        <label>Matriculation Number</label>
        <input type="text" value="<?= htmlspecialchars($student['matric_no']) ?>" disabled>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="text" value="<?= htmlspecialchars($student['email']) ?>" disabled>
      </div>
    </div>
    <div class="form-group">
      <label>Full Name</label>
      <input type="text" name="full_name" value="<?= htmlspecialchars($student['full_name'] ?? '') ?>" required>
    </div>
    <div class="grid cols-2">
      <div class="form-group">
        <label>Phone Number</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($student['phone'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label>Department</label>
        <input type="text" name="department" value="<?= htmlspecialchars($student['department'] ?? '') ?>" placeholder="e.g. Computer Science" required>
      </div>
    </div>
    <div class="form-group">
      <label>Level</label>
      <select name="level" required>
        <?php foreach (['ND1','ND2','HND1','HND2'] as $lvl): ?>
          <option value="<?= $lvl ?>" <?= ($student['level'] ?? '') === $lvl ? 'selected' : '' ?>><?= $lvl ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label>Passport Photograph</label>
      <input type="file" name="passport_photo" id="passport_photo">
      <div class="form-hint" data-file-preview="passport_photo">
        <?= $student['passport_photo'] ? 'Current photo on file. Choose a new file to replace it.' : 'No file chosen' ?>
      </div>
    </div>
    <button class="btn btn-primary btn-block" type="submit">Save Profile</button>
  </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
