<?php
$pageTitle = 'Course Materials';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_completed_profile();

$sid = $_SESSION['student_id'];

$materials = $pdo->prepare(
    "SELECT DISTINCT m.*, c.course_code, c.course_title FROM materials m
     JOIN courses c ON c.id = m.course_id
     JOIN course_registrations cr ON cr.course_id = c.id
     WHERE cr.student_id = ? ORDER BY m.uploaded_at DESC"
);
$materials->execute([$sid]);
$materials = $materials->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="flex-between"><h2>Course Materials</h2></div>

<div class="card">
  <p class="text-muted">Materials shown here are limited to courses you are currently registered for.</p>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Course</th><th>Title</th><th>Uploaded</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($materials as $m): ?>
        <tr>
          <td><?= htmlspecialchars($m['course_code']) ?></td>
          <td><?= htmlspecialchars($m['title']) ?></td>
          <td><?= htmlspecialchars(date('d M Y', strtotime($m['uploaded_at']))) ?></td>
          <td><a class="btn btn-sm btn-primary" href="../uploads/materials/<?= htmlspecialchars($m['file_path']) ?>" target="_blank">Download</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$materials): ?><tr><td colspan="4" class="text-muted">No materials available yet. Materials appear here once you register for a course and your lecturer uploads content.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
