<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/functions.php';
require_student_login();

$flash = get_flash();
$current = basename($_SERVER['PHP_SELF']);

// Keep session profile flag fresh
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$_SESSION['student_id']]);
$loggedInStudent = $stmt->fetch();
if ($loggedInStudent) {
    $_SESSION['profile_completed'] = (bool) $loggedInStudent['profile_completed'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Student Portal' ?> | <?= htmlspecialchars(SCHOOL_SHORT) ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="topbar">
  <div class="container">
    <div class="brand">
      <div class="badge">BU</div>
      <div>
        <h1><?= htmlspecialchars(SCHOOL_NAME) ?></h1>
        <span>Student Portal</span>
      </div>
    </div>
    <nav>
      <span style="margin-right:18px; color:#eafaf1; font-size:14px;">👤 <?= htmlspecialchars($loggedInStudent['full_name'] ?? $loggedInStudent['matric_no'] ?? 'Student') ?></span>
      <a href="logout.php">Logout</a>
    </nav>
  </div>
</header>

<div class="app-shell">
  <aside class="sidebar">
    <a href="dashboard.php" class="<?= $current === 'dashboard.php' ? 'active' : '' ?>">🏠 Dashboard</a>
    <a href="profile.php" class="<?= $current === 'profile.php' ? 'active' : '' ?>">🙍 My Profile</a>
    <a href="course_registration.php" class="<?= $current === 'course_registration.php' ? 'active' : '' ?>">📝 Course Registration</a>
    <a href="upload_project.php" class="<?= $current === 'upload_project.php' ? 'active' : '' ?>">📁 Upload Project</a>
    <a href="results.php" class="<?= $current === 'results.php' ? 'active' : '' ?>">📊 My Results</a>
    <a href="materials.php" class="<?= $current === 'materials.php' ? 'active' : '' ?>">📚 Course Materials</a>
  </aside>
  <main class="content">
    <?php if ($flash): ?>
      <div class="alert alert-<?= $flash['type'] === 'error' ? 'error' : 'success' ?>"><?= htmlspecialchars($flash['message']) ?></div>
    <?php endif; ?>
    <?php if (empty($_SESSION['profile_completed']) && $current !== 'profile.php'): ?>
      <div class="alert alert-info">
        Your profile is incomplete. Please <a href="profile.php"><strong>complete your profile</strong></a> before registering courses or using other features.
      </div>
    <?php endif; ?>
