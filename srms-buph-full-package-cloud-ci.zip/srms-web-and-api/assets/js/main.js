/**
 * Shared front-end behaviour for the SRMS.
 * Countdown reads data-open / data-close ISO datetimes from #reg-countdown.
 */
document.addEventListener('DOMContentLoaded', function () {
  initCountdown();
  initFileNamePreview();
  autoDismissFlash();
});

function initCountdown() {
  const box = document.getElementById('reg-countdown');
  if (!box) return;

  const closeTime = new Date(box.dataset.close).getTime();
  const openTime  = new Date(box.dataset.open).getTime();
  const dEl = document.getElementById('cd-days');
  const hEl = document.getElementById('cd-hours');
  const mEl = document.getElementById('cd-mins');
  const sEl = document.getElementById('cd-secs');
  const statusEl = document.getElementById('cd-status');

  function tick() {
    const now = Date.now();
    let target, label;

    if (now < openTime) {
      target = openTime;
      label = 'Registration opens in:';
    } else if (now <= closeTime) {
      target = closeTime;
      label = 'Registration closes in:';
    } else {
      if (statusEl) statusEl.textContent = 'Registration window has closed.';
      [dEl, hEl, mEl, sEl].forEach(el => { if (el) el.textContent = '00'; });
      clearInterval(timer);
      return;
    }

    if (statusEl) statusEl.textContent = label;
    const diff = Math.max(0, target - now);
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const mins = Math.floor((diff / (1000 * 60)) % 60);
    const secs = Math.floor((diff / 1000) % 60);

    if (dEl) dEl.textContent = String(days).padStart(2, '0');
    if (hEl) hEl.textContent = String(hours).padStart(2, '0');
    if (mEl) mEl.textContent = String(mins).padStart(2, '0');
    if (sEl) sEl.textContent = String(secs).padStart(2, '0');
  }

  tick();
  const timer = setInterval(tick, 1000);
}

// Shows the chosen filename next to file inputs for a nicer UX
function initFileNamePreview() {
  document.querySelectorAll('input[type="file"]').forEach(function (input) {
    input.addEventListener('change', function () {
      const label = document.querySelector('[data-file-preview="' + input.id + '"]');
      if (label) {
        label.textContent = input.files.length ? input.files[0].name : 'No file chosen';
      }
    });
  });
}

// Fades out flash messages automatically after a few seconds
function autoDismissFlash() {
  const alertBox = document.querySelector('.alert');
  if (!alertBox) return;
  setTimeout(function () {
    alertBox.style.transition = 'opacity .6s';
    alertBox.style.opacity = '0';
    setTimeout(() => alertBox.remove(), 600);
  }, 5000);
}

// Confirms destructive actions (delete buttons etc.)
function confirmAction(message) {
  return confirm(message || 'Are you sure you want to proceed?');
}
