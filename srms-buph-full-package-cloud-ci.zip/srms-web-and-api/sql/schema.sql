-- =====================================================================
-- BINYAMINU USMAN POLYTECHNIC, HADEJIA
-- Student Results Management System (SRMS) - Database Schema
-- Import this file in phpMyAdmin (XAMPP) before running the app.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS srms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE srms_db;

-- ---------------------------------------------------------------
-- Admins
-- ---------------------------------------------------------------
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    api_token VARCHAR(64) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- No admin row is inserted here on purpose: passwords must be hashed with
-- PHP's password_hash(), which SQL cannot do on its own. After importing
-- this file, open http://localhost/srms/setup.php ONCE in your browser to
-- create the first admin account (username: admin | password: Admin@123).
-- setup.php deletes/locks itself after first use for security.

-- ---------------------------------------------------------------
-- Students
-- Two-stage signup: account (login credentials) -> profile (must be
-- completed before the student can register courses or use the system)
-- ---------------------------------------------------------------
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matric_no VARCHAR(30) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    department VARCHAR(100) DEFAULT NULL,
    level VARCHAR(10) DEFAULT NULL,          -- e.g. ND1, ND2, HND1, HND2
    passport_photo VARCHAR(255) DEFAULT NULL,
    profile_completed TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('active','suspended') NOT NULL DEFAULT 'active',
    api_token VARCHAR(64) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------
-- Courses (each tied to a session/semester/level/department)
-- ---------------------------------------------------------------
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL,
    course_title VARCHAR(150) NOT NULL,
    unit INT NOT NULL DEFAULT 2,
    department VARCHAR(100) NOT NULL,
    level VARCHAR(10) NOT NULL,
    semester ENUM('First','Second') NOT NULL,
    session VARCHAR(20) NOT NULL,             -- e.g. 2025/2026
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_course (course_code, session, semester, level)
);

-- ---------------------------------------------------------------
-- Registration window / countdown control (per session+semester+level)
-- ---------------------------------------------------------------
CREATE TABLE registration_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session VARCHAR(20) NOT NULL,
    semester ENUM('First','Second') NOT NULL,
    level VARCHAR(10) NOT NULL,
    open_date DATETIME NOT NULL,
    close_date DATETIME NOT NULL,
    is_open TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_window (session, semester, level),
    FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------------
-- Course registrations (with simulated Remita payment reference)
-- ---------------------------------------------------------------
CREATE TABLE course_registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    session VARCHAR(20) NOT NULL,
    semester ENUM('First','Second') NOT NULL,
    remita_rrr VARCHAR(30) NOT NULL,
    remita_account VARCHAR(20) NOT NULL,
    payment_status ENUM('pending','confirmed') NOT NULL DEFAULT 'confirmed',
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_registration (student_id, course_id, session, semester)
);

-- ---------------------------------------------------------------
-- Results
-- ---------------------------------------------------------------
CREATE TABLE results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    session VARCHAR(20) NOT NULL,
    semester ENUM('First','Second') NOT NULL,
    ca_score DECIMAL(5,2) DEFAULT 0,
    exam_score DECIMAL(5,2) DEFAULT 0,
    total_score DECIMAL(5,2) DEFAULT 0,
    grade VARCHAR(2) DEFAULT NULL,
    uploaded_by INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES admins(id) ON DELETE SET NULL,
    UNIQUE KEY unique_result (student_id, course_id, session, semester)
);

-- ---------------------------------------------------------------
-- Teaching materials
-- ---------------------------------------------------------------
CREATE TABLE materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    uploaded_by INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES admins(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------------
-- Student project uploads (with hash for duplicate detection)
-- ---------------------------------------------------------------
CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_hash VARCHAR(64) NOT NULL,
    is_duplicate TINYINT(1) NOT NULL DEFAULT 0,
    duplicate_of INT DEFAULT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    KEY idx_hash (file_hash)
);
