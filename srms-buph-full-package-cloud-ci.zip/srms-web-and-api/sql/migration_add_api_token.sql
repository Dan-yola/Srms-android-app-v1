-- Run this ONLY if you already imported schema.sql before the Android app
-- was added (i.e. your `students` / `admins` tables don't yet have an
-- api_token column). If you're importing schema.sql fresh, skip this file.

ALTER TABLE students ADD COLUMN api_token VARCHAR(64) DEFAULT NULL AFTER status;
ALTER TABLE admins ADD COLUMN api_token VARCHAR(64) DEFAULT NULL AFTER email;
