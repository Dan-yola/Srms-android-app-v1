<?php
// GET /api/get_my_projects.php  (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

$stmt = $pdo->prepare(
    "SELECT p.*, c.course_code FROM projects p JOIN courses c ON c.id = p.course_id
     WHERE p.student_id = ? ORDER BY p.uploaded_at DESC"
);
$stmt->execute([$student['id']]);
$rows = $stmt->fetchAll();

$projects = array_map(function ($p) {
    return [
        'id' => (int) $p['id'],
        'course_code' => $p['course_code'],
        'title' => $p['title'],
        'is_duplicate' => (bool) $p['is_duplicate'],
        'uploaded_at' => $p['uploaded_at'],
        'file_url' => file_url('projects', $p['file_path']),
    ];
}, $rows);

json_out(['success' => true, 'projects' => $projects]);
