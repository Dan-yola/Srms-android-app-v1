<?php
// GET  /api/admin_courses.php                (list all courses)
// POST /api/admin_courses.php  { course_code, course_title, unit, department, level, semester, session }
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_body();
    $code    = strtoupper(clean($data['course_code'] ?? ''));
    $title   = clean($data['course_title'] ?? '');
    $unit    = (int) ($data['unit'] ?? 2);
    $dept    = clean($data['department'] ?? '');
    $level   = clean($data['level'] ?? '');
    $sem     = clean($data['semester'] ?? '');
    $session = clean($data['session'] ?? '');

    if (!$code || !$title || !$dept || !$level || !$sem || !$session) {
        json_error('All course fields are required.');
    }

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO courses (course_code, course_title, unit, department, level, semester, session)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([$code, $title, $unit, $dept, $level, $sem, $session]);
        json_out(['success' => true, 'message' => "Course $code created.", 'id' => (int) $pdo->lastInsertId()]);
    } catch (PDOException $e) {
        json_error('Could not create course — it may already exist for that session/semester/level.', 409);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'DELETE' || isset($_GET['delete'])) {
    $id = (int) ($_GET['delete'] ?? 0);
    $pdo->prepare("DELETE FROM courses WHERE id = ?")->execute([$id]);
    json_out(['success' => true, 'message' => 'Course deleted.']);
}

$courses = $pdo->query("SELECT * FROM courses ORDER BY session DESC, semester, level, course_code")->fetchAll();
foreach ($courses as &$c) { $c['id'] = (int) $c['id']; $c['unit'] = (int) $c['unit']; }
json_out(['success' => true, 'courses' => $courses]);
