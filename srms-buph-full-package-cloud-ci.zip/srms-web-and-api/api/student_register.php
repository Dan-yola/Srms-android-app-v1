<?php
// POST /api/student_register.php
// Body: { "matric_no": "...", "email": "...", "password": "...", "confirm_password": "..." }
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);

$data     = json_body();
$matric   = strtoupper(trim($data['matric_no'] ?? ''));
$email    = trim($data['email'] ?? '');
$password = $data['password'] ?? '';
$confirm  = $data['confirm_password'] ?? '';

if (!$matric || !$email || !$password) json_error('All fields are required.');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_error('Please enter a valid email address.');
if (strlen($password) < 6) json_error('Password must be at least 6 characters long.');
if ($password !== $confirm) json_error('Passwords do not match.');

$check = $pdo->prepare("SELECT id FROM students WHERE matric_no = ? OR email = ?");
$check->execute([$matric, $email]);
if ($check->fetch()) json_error('An account with this matric number or email already exists.');

$hash  = password_hash($password, PASSWORD_DEFAULT);
$token = generate_token();

$stmt = $pdo->prepare(
    "INSERT INTO students (matric_no, email, password, profile_completed, api_token) VALUES (?, ?, ?, 0, ?)"
);
$stmt->execute([$matric, $email, $hash, $token]);

json_out([
    'success' => true,
    'message' => 'Account created. Please complete your profile.',
    'token'   => $token,
    'student' => [
        'id' => (int) $pdo->lastInsertId(),
        'matric_no' => $matric,
        'email' => $email,
        'profile_completed' => false,
    ],
]);
