<?php
// GET /api/get_results.php?session=2025/2026&semester=First  (Authorization: Bearer <token>)
// If session/semester are omitted, returns the list of sessions that have
// results, plus the results for the most recent one.
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

$availStmt = $pdo->prepare(
    "SELECT DISTINCT session, semester FROM results WHERE student_id = ? ORDER BY session DESC, semester"
);
$availStmt->execute([$student['id']]);
$available = $availStmt->fetchAll();

$session  = $_GET['session'] ?? ($available[0]['session'] ?? '');
$semester = $_GET['semester'] ?? ($available[0]['semester'] ?? 'First');

$results = [];
$totalUnits = 0; $totalPoints = 0;
$gradePoints = ['A' => 5, 'B' => 4, 'C' => 3, 'D' => 2, 'E' => 1, 'F' => 0];

if ($session) {
    $resStmt = $pdo->prepare(
        "SELECT r.*, c.course_code, c.course_title, c.unit FROM results r
         JOIN courses c ON c.id = r.course_id
         WHERE r.student_id = ? AND r.session = ? AND r.semester = ?
         ORDER BY c.course_code"
    );
    $resStmt->execute([$student['id'], $session, $semester]);
    $results = $resStmt->fetchAll();

    foreach ($results as &$r) {
        $r['unit'] = (int) $r['unit'];
        $r['ca_score'] = (float) $r['ca_score'];
        $r['exam_score'] = (float) $r['exam_score'];
        $r['total_score'] = (float) $r['total_score'];
        $totalUnits += $r['unit'];
        $totalPoints += $r['unit'] * ($gradePoints[$r['grade']] ?? 0);
    }
}
$gpa = $totalUnits > 0 ? round($totalPoints / $totalUnits, 2) : 0;

json_out([
    'success'   => true,
    'session'   => $session,
    'semester'  => $semester,
    'available_sessions' => $available,
    'results'   => $results,
    'total_units' => $totalUnits,
    'gpa'       => $gpa,
]);
