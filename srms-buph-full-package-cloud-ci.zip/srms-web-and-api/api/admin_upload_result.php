<?php
// POST /api/admin_upload_result.php
// Body: { student_id, course_id, session, semester, ca_score, exam_score }
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);

$data      = json_body();
$studentId = (int) ($data['student_id'] ?? 0);
$courseId  = (int) ($data['course_id'] ?? 0);
$session   = clean($data['session'] ?? '');
$semester  = clean($data['semester'] ?? '');
$ca        = (float) ($data['ca_score'] ?? 0);
$exam      = (float) ($data['exam_score'] ?? 0);

if (!$studentId || !$courseId || !$session || !$semester) {
    json_error('student_id, course_id, session, and semester are all required.');
}

$total = $ca + $exam;
$grade = grade_from_score($total);

$stmt = $pdo->prepare(
    "INSERT INTO results (student_id, course_id, session, semester, ca_score, exam_score, total_score, grade, uploaded_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE ca_score = VALUES(ca_score), exam_score = VALUES(exam_score),
     total_score = VALUES(total_score), grade = VALUES(grade), uploaded_by = VALUES(uploaded_by)"
);
$stmt->execute([$studentId, $courseId, $session, $semester, $ca, $exam, $total, $grade, $admin['id']]);

json_out(['success' => true, 'message' => 'Result saved.', 'total_score' => $total, 'grade' => $grade]);
