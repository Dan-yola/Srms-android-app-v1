<?php
// GET /api/get_courses.php?session=2025/2026&semester=First  (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

$session  = $_GET['session'] ?? '';
$semester = $_GET['semester'] ?? 'First';

if (!$student['level'] || !$student['department']) json_error('Please complete your profile first.');

$courseStmt = $pdo->prepare(
    "SELECT * FROM courses WHERE level = ? AND semester = ? AND session = ?
     AND (department = ? OR department = 'General') ORDER BY course_code"
);
$courseStmt->execute([$student['level'], $semester, $session, $student['department']]);
$courses = $courseStmt->fetchAll();

$regStmt = $pdo->prepare(
    "SELECT course_id FROM course_registrations WHERE student_id = ? AND session = ? AND semester = ?"
);
$regStmt->execute([$student['id'], $session, $semester]);
$registeredIds = array_column($regStmt->fetchAll(), 'course_id');

foreach ($courses as &$c) {
    $c['id'] = (int) $c['id'];
    $c['unit'] = (int) $c['unit'];
    $c['already_registered'] = in_array($c['id'], $registeredIds);
}

json_out(['success' => true, 'courses' => $courses]);
