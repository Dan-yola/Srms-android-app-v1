<?php
// GET /api/admin_get_students.php?q=search  (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare(
        "SELECT * FROM students WHERE full_name LIKE ? OR matric_no LIKE ? OR email LIKE ? ORDER BY created_at DESC"
    );
    $like = "%$search%";
    $stmt->execute([$like, $like, $like]);
} else {
    $stmt = $pdo->query("SELECT * FROM students ORDER BY created_at DESC");
}
$rows = $stmt->fetchAll();

$students = array_map(function ($s) {
    return [
        'id' => (int) $s['id'],
        'matric_no' => $s['matric_no'],
        'full_name' => $s['full_name'],
        'email' => $s['email'],
        'department' => $s['department'],
        'level' => $s['level'],
        'profile_completed' => (bool) $s['profile_completed'],
        'status' => $s['status'],
    ];
}, $rows);

json_out(['success' => true, 'students' => $students]);
