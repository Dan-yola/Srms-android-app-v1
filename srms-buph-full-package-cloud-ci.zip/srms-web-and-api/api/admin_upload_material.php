<?php
// GET    /api/admin_upload_material.php                (list all materials)
// GET    /api/admin_upload_material.php?delete=5        (delete a material)
// POST   /api/admin_upload_material.php  (multipart/form-data, Authorization: Bearer <token>)
//        Fields: course_id, title, material_file (file)
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $pdo->prepare("SELECT file_path FROM materials WHERE id = ?");
    $stmt->execute([$id]);
    $m = $stmt->fetch();
    if ($m) {
        @unlink(UPLOAD_MATERIALS_DIR . $m['file_path']);
        $pdo->prepare("DELETE FROM materials WHERE id = ?")->execute([$id]);
    }
    json_out(['success' => true, 'message' => 'Material deleted.']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $rows = $pdo->query(
        "SELECT m.*, c.course_code FROM materials m JOIN courses c ON c.id = m.course_id ORDER BY m.uploaded_at DESC"
    )->fetchAll();
    $materials = array_map(function ($m) {
        return [
            'id' => (int) $m['id'],
            'course_code' => $m['course_code'],
            'title' => $m['title'],
            'uploaded_at' => $m['uploaded_at'],
            'file_url' => file_url('materials', $m['file_path']),
        ];
    }, $rows);
    json_out(['success' => true, 'materials' => $materials]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);

$courseId = (int) ($_POST['course_id'] ?? 0);
$title    = clean($_POST['title'] ?? '');

if (!$courseId || !$title) json_error('course_id and title are required.');
if (empty($_FILES['material_file']['name'])) json_error('Please attach a file.');

$allowed = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'zip'];
$ext = strtolower(pathinfo($_FILES['material_file']['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowed)) {
    json_error('Invalid file type. Allowed: ' . implode(', ', $allowed));
}

$newName = 'material_' . uniqid() . '.' . $ext;
if (!is_dir(UPLOAD_MATERIALS_DIR)) mkdir(UPLOAD_MATERIALS_DIR, 0777, true);
move_uploaded_file($_FILES['material_file']['tmp_name'], UPLOAD_MATERIALS_DIR . $newName);

$stmt = $pdo->prepare("INSERT INTO materials (course_id, title, file_path, uploaded_by) VALUES (?, ?, ?, ?)");
$stmt->execute([$courseId, $title, $newName, $admin['id']]);

json_out(['success' => true, 'message' => 'Material uploaded successfully.']);
