<?php
// POST /api/upload_project.php  (multipart/form-data, Authorization: Bearer <token>)
// Fields: course_id, title, project_file (file)
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);
if (!$student['profile_completed']) json_error('Please complete your profile first.', 403);

$courseId = (int) ($_POST['course_id'] ?? 0);
$title    = clean($_POST['title'] ?? '');

if (!$courseId || !$title) json_error('course_id and title are required.');
if (empty($_FILES['project_file']['name'])) json_error('Please attach a project file.');

$allowed = ['pdf', 'doc', 'docx', 'zip', 'rar'];
$ext = strtolower(pathinfo($_FILES['project_file']['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowed)) {
    json_error('Invalid file type. Allowed: ' . implode(', ', $allowed));
}

$tmpPath = $_FILES['project_file']['tmp_name'];
$fileHash = hash_file('sha256', $tmpPath);

$dupStmt = $pdo->prepare(
    "SELECT p.id, s.full_name, s.matric_no FROM projects p
     JOIN students s ON s.id = p.student_id
     WHERE p.course_id = ? AND p.file_hash = ? LIMIT 1"
);
$dupStmt->execute([$courseId, $fileHash]);
$duplicateOf = $dupStmt->fetch();

$newName = 'project_' . $student['id'] . '_' . uniqid() . '.' . $ext;
if (!is_dir(UPLOAD_PROJECTS_DIR)) mkdir(UPLOAD_PROJECTS_DIR, 0777, true);
move_uploaded_file($tmpPath, UPLOAD_PROJECTS_DIR . $newName);

$isDuplicate = $duplicateOf ? 1 : 0;
$duplicateId = $duplicateOf['id'] ?? null;

$stmt = $pdo->prepare(
    "INSERT INTO projects (student_id, course_id, title, file_path, file_hash, is_duplicate, duplicate_of)
     VALUES (?, ?, ?, ?, ?, ?, ?)"
);
$stmt->execute([$student['id'], $courseId, $title, $newName, $fileHash, $isDuplicate, $duplicateId]);

json_out([
    'success' => true,
    'is_duplicate' => (bool) $isDuplicate,
    'message' => $isDuplicate
        ? "Warning: this file matches a project already submitted by {$duplicateOf['full_name']} ({$duplicateOf['matric_no']}). Your submission was recorded and flagged for admin review."
        : 'Project uploaded successfully.',
]);
