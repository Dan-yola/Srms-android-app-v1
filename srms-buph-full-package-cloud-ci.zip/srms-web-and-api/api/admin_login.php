<?php
// POST /api/admin_login.php
// Body: { "username": "...", "password": "..." }
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);

$data     = json_body();
$username = trim($data['username'] ?? '');
$password = $data['password'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
$stmt->execute([$username]);
$admin = $stmt->fetch();

if (!$admin || !password_verify($password, $admin['password'])) {
    json_error('Invalid username or password.', 401);
}

$token = generate_token();
$pdo->prepare("UPDATE admins SET api_token = ? WHERE id = ?")->execute([$token, $admin['id']]);

json_out([
    'success' => true,
    'token'   => $token,
    'admin'   => [
        'id' => (int) $admin['id'],
        'username' => $admin['username'],
        'full_name' => $admin['full_name'],
    ],
]);
