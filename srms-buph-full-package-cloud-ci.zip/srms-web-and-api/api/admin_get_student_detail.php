<?php
// GET  /api/admin_get_student_detail.php?id=5              (Authorization: Bearer <token>)
// POST /api/admin_get_student_detail.php  { "id":5, "toggle_status": true }
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_body();
    $id = (int) ($data['id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$id]);
    $student = $stmt->fetch();
    if (!$student) json_error('Student not found.', 404);

    if (!empty($data['toggle_status'])) {
        $newStatus = $student['status'] === 'active' ? 'suspended' : 'active';
        $pdo->prepare("UPDATE students SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
        json_out(['success' => true, 'message' => "Student status changed to $newStatus.", 'status' => $newStatus]);
    }
    json_error('No action specified.');
}

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();
if (!$student) json_error('Student not found.', 404);

$regs = $pdo->prepare(
    "SELECT cr.*, c.course_code, c.course_title FROM course_registrations cr
     JOIN courses c ON c.id = cr.course_id WHERE cr.student_id = ? ORDER BY cr.registered_at DESC"
);
$regs->execute([$id]);

$res = $pdo->prepare(
    "SELECT r.*, c.course_code, c.course_title FROM results r
     JOIN courses c ON c.id = r.course_id WHERE r.student_id = ? ORDER BY r.uploaded_at DESC"
);
$res->execute([$id]);

$proj = $pdo->prepare(
    "SELECT p.*, c.course_code FROM projects p
     JOIN courses c ON c.id = p.course_id WHERE p.student_id = ? ORDER BY p.uploaded_at DESC"
);
$proj->execute([$id]);

json_out([
    'success' => true,
    'student' => [
        'id' => (int) $student['id'],
        'matric_no' => $student['matric_no'],
        'full_name' => $student['full_name'],
        'email' => $student['email'],
        'phone' => $student['phone'],
        'department' => $student['department'],
        'level' => $student['level'],
        'status' => $student['status'],
        'profile_completed' => (bool) $student['profile_completed'],
        'passport_photo_url' => file_url('profile_photos', $student['passport_photo']),
    ],
    'registrations' => $regs->fetchAll(),
    'results' => $res->fetchAll(),
    'projects' => array_map(function ($p) {
        $p['file_url'] = file_url('projects', $p['file_path']);
        $p['is_duplicate'] = (bool) $p['is_duplicate'];
        return $p;
    }, $proj->fetchAll()),
]);
