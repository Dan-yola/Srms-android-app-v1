<?php
// GET /api/admin_projects.php?filter=duplicate   (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

$filter = $_GET['filter'] ?? 'all';
$sql = "SELECT p.*, s.full_name, s.matric_no, c.course_code
        FROM projects p
        JOIN students s ON s.id = p.student_id
        JOIN courses c ON c.id = p.course_id";
if ($filter === 'duplicate') $sql .= " WHERE p.is_duplicate = 1";
$sql .= " ORDER BY p.uploaded_at DESC";

$rows = $pdo->query($sql)->fetchAll();
$projects = array_map(function ($p) {
    return [
        'id' => (int) $p['id'],
        'full_name' => $p['full_name'],
        'matric_no' => $p['matric_no'],
        'course_code' => $p['course_code'],
        'title' => $p['title'],
        'uploaded_at' => $p['uploaded_at'],
        'is_duplicate' => (bool) $p['is_duplicate'],
        'file_url' => file_url('projects', $p['file_path']),
    ];
}, $rows);

json_out(['success' => true, 'projects' => $projects]);
