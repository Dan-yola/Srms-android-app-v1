<?php
// GET /api/get_my_courses.php  (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

$stmt = $pdo->prepare(
    "SELECT DISTINCT c.* FROM courses c
     JOIN course_registrations cr ON cr.course_id = c.id
     WHERE cr.student_id = ? ORDER BY c.course_code"
);
$stmt->execute([$student['id']]);
$courses = $stmt->fetchAll();
foreach ($courses as &$c) { $c['id'] = (int) $c['id']; $c['unit'] = (int) $c['unit']; }

json_out(['success' => true, 'courses' => $courses]);
