<?php
/**
 * Shared bootstrap for every /api/*.php endpoint.
 * Returns JSON only — this file is included at the top of every endpoint.
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

function json_out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function json_error($message, $code = 400) {
    json_out(['success' => false, 'message' => $message], $code);
}

function json_body() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function bearer_token() {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Bearer\s+(\S+)/i', $header, $m)) {
        return $m[1];
    }
    // Fallback for servers that strip the Authorization header
    return $_POST['token'] ?? $_GET['token'] ?? '';
}

function generate_token() {
    return bin2hex(random_bytes(32));
}

// Returns the authenticated student row or sends a 401 JSON error.
function auth_student(PDO $pdo) {
    $token = bearer_token();
    if (!$token) json_error('Missing authentication token.', 401);

    $stmt = $pdo->prepare("SELECT * FROM students WHERE api_token = ?");
    $stmt->execute([$token]);
    $student = $stmt->fetch();

    if (!$student) json_error('Invalid or expired session. Please log in again.', 401);
    if ($student['status'] === 'suspended') json_error('Your account has been suspended.', 403);

    return $student;
}

// Returns the authenticated admin row or sends a 401 JSON error.
function auth_admin(PDO $pdo) {
    $token = bearer_token();
    if (!$token) json_error('Missing authentication token.', 401);

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE api_token = ?");
    $stmt->execute([$token]);
    $admin = $stmt->fetch();

    if (!$admin) json_error('Invalid or expired session. Please log in again.', 401);
    return $admin;
}

// Builds a full public URL for a file stored under /uploads/<folder>/
function file_url($folder, $filename) {
    if (!$filename) return null;
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $base = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/'); // strips /api
    return "$scheme://$host$base/uploads/$folder/$filename";
}
