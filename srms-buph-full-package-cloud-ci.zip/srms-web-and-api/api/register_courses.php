<?php
// POST /api/register_courses.php  (Authorization: Bearer <token>)
// Body: { "session": "2025/2026", "semester": "First", "course_ids": [1,2,3] }
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);
if (!$student['profile_completed']) json_error('Please complete your profile before registering courses.', 403);

$data      = json_body();
$session   = clean($data['session'] ?? '');
$semester  = clean($data['semester'] ?? '');
$courseIds = $data['course_ids'] ?? [];

if (!$session || !$semester || !$courseIds) {
    json_error('session, semester, and at least one course_id are required.');
}

$window = get_registration_window($pdo, $session, $semester, $student['level']);
if (!$window['exists'] || !$window['open']) {
    json_error('Registration is not currently open for this session/semester. You cannot register or generate a Remita reference yet.', 403);
}

$rrr = generate_rrr();
$insertedCount = 0;
$insertedCourses = [];

foreach ($courseIds as $courseId) {
    $courseId = (int) $courseId;
    try {
        $ins = $pdo->prepare(
            "INSERT INTO course_registrations (student_id, course_id, session, semester, remita_rrr, remita_account, payment_status)
             VALUES (?, ?, ?, ?, ?, ?, 'confirmed')"
        );
        $ins->execute([$student['id'], $courseId, $session, $semester, $rrr, REMITA_SCHOOL_ACCOUNT]);
        $insertedCount++;
        $insertedCourses[] = $courseId;
    } catch (PDOException $e) {
        // Already registered for this course this session/semester — skip
    }
}

if ($insertedCount === 0) {
    json_error('You are already registered for the selected course(s).', 409);
}

json_out([
    'success' => true,
    'message' => "$insertedCount course(s) registered successfully.",
    'remita_rrr' => $rrr,
    'remita_account' => REMITA_SCHOOL_ACCOUNT,
    'registered_course_ids' => $insertedCourses,
]);
