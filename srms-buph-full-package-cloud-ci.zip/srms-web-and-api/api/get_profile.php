<?php
// GET /api/get_profile.php  (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

json_out([
    'success' => true,
    'student' => [
        'id'                => (int) $student['id'],
        'matric_no'         => $student['matric_no'],
        'email'             => $student['email'],
        'full_name'         => $student['full_name'],
        'phone'             => $student['phone'],
        'department'        => $student['department'],
        'level'             => $student['level'],
        'passport_photo_url'=> file_url('profile_photos', $student['passport_photo']),
        'profile_completed' => (bool) $student['profile_completed'],
    ],
]);
