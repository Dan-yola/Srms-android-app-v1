<?php
// GET  /api/admin_registration_settings.php                     (list all windows)
// POST /api/admin_registration_settings.php  { session, semester, level, open_date, close_date }
// POST /api/admin_registration_settings.php  { id, set_open: true|false }   (close/reopen)
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_body();

    if (isset($data['id']) && isset($data['set_open'])) {
        $pdo->prepare("UPDATE registration_settings SET is_open = ? WHERE id = ?")
            ->execute([$data['set_open'] ? 1 : 0, (int) $data['id']]);
        json_out(['success' => true, 'message' => $data['set_open'] ? 'Window reopened.' : 'Window closed.']);
    }

    $session   = clean($data['session'] ?? '');
    $semester  = clean($data['semester'] ?? '');
    $level     = clean($data['level'] ?? '');
    $openDate  = $data['open_date'] ?? '';
    $closeDate = $data['close_date'] ?? '';

    if (!$session || !$semester || !$level || !$openDate || !$closeDate) {
        json_error('session, semester, level, open_date, and close_date are all required.');
    }

    $stmt = $pdo->prepare(
        "INSERT INTO registration_settings (session, semester, level, open_date, close_date, is_open, created_by)
         VALUES (?, ?, ?, ?, ?, 1, ?)
         ON DUPLICATE KEY UPDATE open_date = VALUES(open_date), close_date = VALUES(close_date), is_open = 1"
    );
    $stmt->execute([$session, $semester, $level, $openDate, $closeDate, $admin['id']]);
    json_out(['success' => true, 'message' => "Registration window saved for $level — $semester Semester, $session."]);
}

$windows = $pdo->query("SELECT * FROM registration_settings ORDER BY session DESC, semester, level")->fetchAll();
$now = new DateTime();
foreach ($windows as &$w) {
    $w['id'] = (int) $w['id'];
    $open = new DateTime($w['open_date']);
    $close = new DateTime($w['close_date']);
    $w['currently_open'] = (bool) ($w['is_open'] && $now >= $open && $now <= $close);
}
json_out(['success' => true, 'windows' => $windows]);
