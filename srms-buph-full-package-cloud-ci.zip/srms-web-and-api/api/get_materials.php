<?php
// GET /api/get_materials.php  (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

$stmt = $pdo->prepare(
    "SELECT DISTINCT m.*, c.course_code, c.course_title FROM materials m
     JOIN courses c ON c.id = m.course_id
     JOIN course_registrations cr ON cr.course_id = c.id
     WHERE cr.student_id = ? ORDER BY m.uploaded_at DESC"
);
$stmt->execute([$student['id']]);
$rows = $stmt->fetchAll();

$materials = array_map(function ($m) {
    return [
        'id' => (int) $m['id'],
        'course_code' => $m['course_code'],
        'title' => $m['title'],
        'uploaded_at' => $m['uploaded_at'],
        'file_url' => file_url('materials', $m['file_path']),
    ];
}, $rows);

json_out(['success' => true, 'materials' => $materials]);
