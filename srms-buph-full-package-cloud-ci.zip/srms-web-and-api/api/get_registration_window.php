<?php
// GET /api/get_registration_window.php?session=2025/2026&semester=First
// (Authorization: Bearer <token>) — level is taken from the student's profile
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

$session  = $_GET['session'] ?? '';
$semester = $_GET['semester'] ?? 'First';

if (!$student['level']) json_error('Please complete your profile first.');

$window = get_registration_window($pdo, $session, $semester, $student['level']);

json_out([
    'success' => true,
    'exists'  => $window['exists'],
    'open'    => $window['open'] ?? false,
    'open_date'  => $window['open_date'] ?? null,
    'close_date' => $window['close_date'] ?? null,
    'server_time' => date('c'),
]);
