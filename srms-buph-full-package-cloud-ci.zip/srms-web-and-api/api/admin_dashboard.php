<?php
// GET /api/admin_dashboard.php  (Authorization: Bearer <token>)
require_once __DIR__ . '/bootstrap.php';
$admin = auth_admin($pdo);

json_out([
    'success' => true,
    'stats' => [
        'total_students'     => (int) $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'],
        'total_courses'      => (int) $pdo->query("SELECT COUNT(*) c FROM courses")->fetch()['c'],
        'total_registrations'=> (int) $pdo->query("SELECT COUNT(*) c FROM course_registrations")->fetch()['c'],
        'total_projects'     => (int) $pdo->query("SELECT COUNT(*) c FROM projects")->fetch()['c'],
        'duplicate_projects' => (int) $pdo->query("SELECT COUNT(*) c FROM projects WHERE is_duplicate = 1")->fetch()['c'],
    ],
]);
