<?php
// POST /api/student_login.php
// Body: { "matric_no": "...", "password": "..." }
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);

$data     = json_body();
$matric   = strtoupper(trim($data['matric_no'] ?? ''));
$password = $data['password'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM students WHERE matric_no = ?");
$stmt->execute([$matric]);
$student = $stmt->fetch();

if (!$student || !password_verify($password, $student['password'])) {
    json_error('Invalid matric number or password.', 401);
}
if ($student['status'] === 'suspended') {
    json_error('Your account has been suspended. Please contact the school administration.', 403);
}

$token = generate_token();
$pdo->prepare("UPDATE students SET api_token = ? WHERE id = ?")->execute([$token, $student['id']]);

json_out([
    'success' => true,
    'token'   => $token,
    'student' => [
        'id'                => (int) $student['id'],
        'matric_no'         => $student['matric_no'],
        'email'             => $student['email'],
        'full_name'         => $student['full_name'],
        'phone'             => $student['phone'],
        'department'        => $student['department'],
        'level'             => $student['level'],
        'passport_photo_url'=> file_url('profile_photos', $student['passport_photo']),
        'profile_completed' => (bool) $student['profile_completed'],
    ],
]);
