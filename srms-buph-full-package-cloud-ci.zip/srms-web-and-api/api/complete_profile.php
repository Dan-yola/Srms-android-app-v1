<?php
// POST /api/complete_profile.php  (multipart/form-data, Authorization: Bearer <token>)
// Fields: full_name, phone, department, level, passport_photo (file, optional)
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('POST required.', 405);

$fullName = clean($_POST['full_name'] ?? '');
$phone    = clean($_POST['phone'] ?? '');
$dept     = clean($_POST['department'] ?? '');
$level    = clean($_POST['level'] ?? '');

if (!$fullName || !$phone || !$dept || !$level) {
    json_error('full_name, phone, department, and level are all required.');
}

$photoName = $student['passport_photo'];
if (!empty($_FILES['passport_photo']['name'])) {
    $allowed = ['jpg', 'jpeg', 'png'];
    $ext = strtolower(pathinfo($_FILES['passport_photo']['name'], PATHINFO_EXTENSION));
    if (in_array($ext, $allowed)) {
        $photoDir = __DIR__ . '/../uploads/profile_photos/';
        if (!is_dir($photoDir)) mkdir($photoDir, 0777, true);
        $photoName = 'photo_' . $student['id'] . '_' . uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['passport_photo']['tmp_name'], $photoDir . $photoName);
    }
}

$stmt = $pdo->prepare(
    "UPDATE students SET full_name = ?, phone = ?, department = ?, level = ?, passport_photo = ?, profile_completed = 1 WHERE id = ?"
);
$stmt->execute([$fullName, $phone, $dept, $level, $photoName, $student['id']]);

json_out([
    'success' => true,
    'message' => 'Profile saved successfully.',
    'student' => [
        'id'                => (int) $student['id'],
        'matric_no'         => $student['matric_no'],
        'email'             => $student['email'],
        'full_name'         => $fullName,
        'phone'             => $phone,
        'department'        => $dept,
        'level'             => $level,
        'passport_photo_url'=> file_url('profile_photos', $photoName),
        'profile_completed' => true,
    ],
]);
