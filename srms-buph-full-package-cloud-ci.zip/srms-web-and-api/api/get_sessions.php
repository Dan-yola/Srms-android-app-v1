<?php
// GET /api/get_sessions.php  (Authorization: Bearer <token>)
// Returns every session/semester window configured for the student's level,
// so the app can populate a picker instead of hardcoding sessions.
require_once __DIR__ . '/bootstrap.php';
$student = auth_student($pdo);

if (!$student['level']) json_error('Please complete your profile first.');

$stmt = $pdo->prepare(
    "SELECT session, semester, open_date, close_date, is_open FROM registration_settings
     WHERE level = ? ORDER BY session DESC, semester"
);
$stmt->execute([$student['level']]);
$rows = $stmt->fetchAll();

json_out(['success' => true, 'windows' => $rows]);
