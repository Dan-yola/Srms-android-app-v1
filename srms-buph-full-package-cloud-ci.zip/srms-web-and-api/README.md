# SRMS — Student Results Management System
**BINYAMINU USMAN POLYTECHNIC, HADEJIA**

A PHP + MySQL + JavaScript + HTML/CSS results management system built for
XAMPP and VS Code.

## Features

**Admin**
- Secure login (hashed passwords)
- View all students, their profiles, registrations, results, and project uploads
- Suspend / reactivate student accounts
- Create courses, categorized by **Session → Semester (First/Second) → Level**
- Open/close a **registration window** (countdown) per session/semester/level
- Upload/enter student results (CA + Exam, auto-computed grade)
- Upload teaching materials per course
- Review all student project submissions, with **automatic duplicate flags**

**Student**
- Two-stage sign up: create an account first, then you're **required to
  complete your profile** before you can register courses or use the rest
  of the system
- Course registration — only possible while the admin's registration
  window is open, shown to the student as a **live countdown**
- A simulated **Remita-style payment reference (RRR)** is generated on
  registration, tied to the school's designated collection account
  **`1646445316`**
- Upload projects — the system hashes every uploaded file and **flags
  duplicate submissions** automatically (matched against everyone else's
  submissions for that course)
- View and print/download official result slips (with computed GPA)
- Download teaching materials for registered courses only

> **Note on "Remita":** This project simulates a Remita-style reference
> generation flow for a school project. It does **not** connect to Remita's
> real payment gateway or move real money — it only generates a reference
> number and records it against the school's account number, exactly like
> older polytechnic portals used to display a payment reference before
> hooking up a live payment gateway. If you need real payments, you'd
> integrate Remita's actual REST API (RRR generation endpoint) using your
> merchant credentials, in `student/course_registration.php`.

## Folder Structure

```
srms/
├── admin/                 Admin panel pages
│   └── includes/          Shared header/footer for admin pages
├── student/                Student portal pages
│   └── includes/          Shared header/footer for student pages
├── config/
│   ├── db.php              Database connection + constants
│   └── functions.php        Shared helper functions
├── assets/
│   ├── css/style.css        Shared stylesheet
│   └── js/main.js           Countdown timer + small UX helpers
├── uploads/
│   ├── results/, materials/, projects/, profile_photos/
├── sql/schema.sql            Database schema (import this first)
├── setup.php                 One-time script to create the first admin
└── index.php                 Public landing page
```

## Setup (XAMPP + VS Code)

1. **Copy the project** into your XAMPP `htdocs` folder, e.g.
   `C:\xampp\htdocs\srms` (Windows) or `/Applications/XAMPP/htdocs/srms` (Mac).

2. **Start Apache and MySQL** from the XAMPP Control Panel.

3. **Create the database**:
   - Open `http://localhost/phpmyadmin`
   - Click **Import**, choose `sql/schema.sql`, and run it.
   - This creates the `srms_db` database and all tables (no admin account
     yet — see next step).

4. **Create your first admin account**:
   - Visit `http://localhost/srms/setup.php` in your browser.
   - Fill in a username/password and submit. This safely hashes the
     password with PHP's `password_hash()` and creates the admin.
   - The script locks itself after first use. For extra safety, delete
     `setup.php` and `setup.lock` afterwards.

5. **Open the project in VS Code** to edit anything further (PHP Intelephense
   / "PHP Server" extensions are handy, but not required since XAMPP serves
   the files).

6. **Visit the app**:
   - Landing page: `http://localhost/srms/`
   - Admin login: `http://localhost/srms/admin/login.php`
   - Student sign up: `http://localhost/srms/student/register.php`

## Typical First-Run Workflow

1. Log in as **admin** → go to **Courses** → add courses for a
   Session/Semester/Level/Department.
2. Go to **Registration Window** → set an open/close date+time for that
   same Session/Semester/Level. Registration is only possible for students
   while "now" falls inside this window.
3. A **student** signs up (`register.php`), then is forced to complete
   their profile (name, phone, department, level, photo) before anything
   else works.
4. The student opens **Course Registration** — sees the live countdown,
   and (only while the window is open) selects courses and generates
   their Remita reference to complete registration.
5. Admin uploads **results** and **materials** per course.
6. Student views/downloads **results** and **materials**, and uploads
   **projects** (auto-checked for duplicates).

## Security Notes / Things to Harden Before Real Deployment

- Change the default MySQL root password in `config/db.php` if your XAMPP
  install uses one.
- `setup.php` should be deleted after creating the admin account.
- File uploads are restricted by extension; for production, also validate
  MIME type and scan uploads with antivirus tooling.
- Sessions currently rely on PHP's default session handling — for
  production, tighten session cookie flags (`session.cookie_httponly`,
  `session.cookie_secure` over HTTPS).
- The Remita integration here is a simulation for coursework/demo purposes.
