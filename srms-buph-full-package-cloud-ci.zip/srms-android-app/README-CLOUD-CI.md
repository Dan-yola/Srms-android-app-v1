# SRMS Android App — Cloud/CI Build

This Android project is configured to build the APK in **GitHub Actions (cloud CI)**.

## What changed

- Added `.github/workflows/android-build.yml`.
- The workflow uses Ubuntu in GitHub's cloud.
- It installs/configures JDK 17, Android SDK 34, and Gradle 8.6.
- It runs `clean assembleDebug`.
- The resulting `app-debug.apk` is uploaded as a GitHub Actions artifact.
- You do **not** need Android Studio installed on the computer that performs the cloud build.
- You still need a GitHub repository to run the workflow.

## How to build the APK in the cloud

1. Create/sign in to a GitHub account.
2. Create a **new repository** (for example, `srms-buph`).
3. Upload the contents of this package to the repository, keeping these folders:
   - `srms-android-app/`
   - `.github/workflows/android-build.yml`
   - `srms-web-and-api/`
4. Open the repository on GitHub.
5. Select **Actions**.
6. Choose **Build SRMS Android App (Cloud CI)**.
7. Click **Run workflow**.
8. Wait until the workflow finishes with a green check.
9. Open the completed workflow run.
10. Under **Artifacts**, download **srms-debug-apk**.
11. Extract the downloaded artifact and install `app-debug.apk` on an Android phone.

## Important

This workflow creates a **debug APK for testing**. It is not a Play Store release package and it is not signed with a personal release key.

The PHP/MySQL backend is still required for the app's real data. Cloud CI only builds the Android application; it does not automatically host the PHP/MySQL server.

For local development, Android Studio can still be used, but it is no longer required just to produce a test APK.
