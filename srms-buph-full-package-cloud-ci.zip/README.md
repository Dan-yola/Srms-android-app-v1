# BUPH SRMS — Complete Package

**BINYAMINU USMAN POLYTECHNIC, HADEJIA — Student Results Management System**

This package contains two components that share one MySQL database:

## 1. `srms-web-and-api/`
The PHP + MySQL + JS + HTML/CSS website (for XAMPP), PLUS a JSON REST API
under `srms-web-and-api/api/` that the Android app talks to. Start here —
set up the database and website first. See `srms-web-and-api/README.md`.

## 2. `srms-android-app/`
A native Kotlin Android Studio project implementing the same system as a
mobile app (student + admin), talking to the API above. See
`srms-android-app/README.md`.

## Setup order
1. Put `srms-web-and-api/` in XAMPP's `htdocs/` (rename the folder to
   `srms` if you want the default URLs in both READMEs to work as-is).
2. Import `sql/schema.sql` in phpMyAdmin, then visit `setup.php` once to
   create your admin account.
3. Confirm the website works at `http://localhost/srms/`.
4. Open `srms-android-app/` in Android Studio, sync Gradle, and run it —
   it talks to the same server at `http://10.0.2.2/srms/api/` by default
   (emulator) or a LAN IP you set in the app's Server Settings (real device).

A student or admin can use the website and the app interchangeably — both
read and write the same database.
